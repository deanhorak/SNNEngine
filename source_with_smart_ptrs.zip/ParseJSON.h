#pragma once

#include "Brain.h"

class ParseJSON
{
	Brain* loadFromJSON(void);
};

