#ifndef HTTPSERVERMAIN_H_
#define HTTPSERVERMAIN_H_
#include <string>

//std::string  computeResponse(const std::string content);

#endif  // HTTPSERVERMAIN_H_