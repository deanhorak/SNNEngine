#include "Process.h"
#include "Global.h"

Process::Process(ComponentType type): 
	NNComponent(type)
{
}

Process::~Process(void)
{
}

void Process::setRate(float value) 
{ 
	if(rate != value) {
		//std::cout << "Process " << this->id << " rate chg from " << this->rate << " to " << value << std::endl;
		rate = value; 
		setDirty(true); 
	}
};