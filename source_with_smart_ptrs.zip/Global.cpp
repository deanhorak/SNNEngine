#include <ctime>
#include "Global.h"

FILE *logFile;
int logMemoryAllocations;

char *ctypes[] = {"ComponentTypeUnknown", "ComponentTypeBrain", "ComponentTypeRegion", "ComponentTypeNucleus", "ComponentTypeColumn", "ComponentTypeLayer",
				  "ComponentTypeCluster", "ComponentTypeNeuron", "ComponentTypeAxon", "ComponentTypeDendrite", "ComponentTypeSynapse",
				  "ComponentTypeActionPotential", "ComponentTypeTimedEvent"};

Global::Global(void) : neuronDB(30000), clusterDB(1000), dendriteDB(500000), synapseDB(500000), axonDB(30000)
{
	// Initialize component counters with 100 million gap between
	std::stringstream ss;
	for (size_t i = 0; i < CTYPE_COUNT; i++)
	{
		long index = (long)i;
		componentBase[i] = 100000000 * index;
		componentCounter[i] = componentBase[i];
		componentCounter2[i] = 0;

		LOGSTREAM(ss) << "Component " << ctypes[i] << " assigned values starting at  " << componentCounter[i] << std::endl;
		log(ss);

		//		std::cout << "Component " << ctypes[i] << " assigned values starting at  " << componentCounter[i] << std::endl;
	}

	current_timestep = 0;
	logMemoryAllocations = 0;
	startRealTime = boost::posix_time::microsec_clock::local_time();

	for (size_t i = 0; i < MAX_TIMEINTERVAL_BUFFER_SIZE; i++)
	{
        timeIntervalEvents[i] = std::vector<std::shared_ptr<TimedEvent>>(); // Properly construct empty vectors of smart pointers
        backupTimeIntervalEvents[i] = std::vector<std::shared_ptr<TimedEvent>>(); // Properly construct empty vectors of smart pointers
		teVector_mutex.push_back(new boost::mutex());
	}

	syncpoint = -1;

	logFile = NULL;

	workers = new boost::asio::thread_pool(MAX_THREADPOOL_SIZE); // MAX_THREADPOOL_SIZE threads for now
}

Global::~Global(void)
{
}

size_t Global::getTypeIndex(std::string name)
{
	for (int i = 0; i < CTYPE_COUNT; i++)
	{
		if (name == std::string(ctypes[i]))
		{
			return i;
		}
	}
	return -1;
}

char *Global::allocClearedMemory(size_t count)
{
	if (logFile == NULL)
	{
		if (logMemoryAllocations)
			logFile = fopen((std::string(DB_PATH) + BRAINDEMONAME + std::string("/") + std::string("DebugLogFile.txt")).c_str(), "w");
	}

	if (logMemoryAllocations)
		fprintf(logFile, "Allocating %d bytes...\r", (int)count);

	char *mem = new char[count]; // calloc(count, 1);
	memset(mem, '\0', count);

	if (logMemoryAllocations)
		fprintf(logFile, "%d (0x%llx) bytes Allocated\n", (int)count, (unsigned __int64)mem);

	return mem;
}

void Global::freeMemory(char *mem)
{
	unsigned __int64 ptr = (unsigned __int64)mem;
	char *memPtr = (char *)mem;

	if (logFile == NULL)
	{
		if (logMemoryAllocations)
			logFile = fopen((std::string(DB_PATH) + BRAINDEMONAME + std::string("/") + std::string("DebugLogFile.txt")).c_str(), "w");
	}

	if (logMemoryAllocations)
		fprintf(logFile, "Deallocating 0x%llx\r", ptr);

	delete[] memPtr;

	if (logMemoryAllocations)
		fprintf(logFile, "0x%llx deallocated\n", ptr);
}

void Global::increment(void)
{
	boost::mutex::scoped_lock amx(timestep_mutex);
	current_timestep++;
}

long Global::nextComponent(ComponentType type)
{
	if (type == 3)
	{
		int test = 3;
	}
	return componentCounter[type]++;
}

void Global::removeAP(ActionPotential *ap)
{
	boost::mutex::scoped_lock amx(actionpotential_mutex);
	//removeAPNoMux(ap);
}

void Global::removeAPNoMux(ActionPotential *ap) // special nomux access
{
	try
	{
		if (ap->id >= componentBase[ComponentTypeActionPotential] && ap->id < componentBase[ComponentTypeTimedEvent]) // Check for valid AP range
		{
			bool found = false;
			try
			{

				if (actionpotentials.find(ap->id) != actionpotentials.end())
				{
					size_t found = actionpotentials.erase(ap->id);
					if (!found)
					{
						printf("Invalid Action potential ID %ld encountered\n", ap->id);
					}
					else
					{
						// printf("Action potential ID %ld removed.\n", ap->id);
						bool found = true;
					}
				}
				else
				{
					// printf("Action potential %ld not found\n",ap->id);
				}
			}
			catch (...)
			{
				printf("Invalid Action potential ID encountered\n");
			}
			if (found)
			{
				try
				{
					delete ap;
				}
				catch (...)
				{
					printf("Invalid Action potential object encountered");
				}
			}
		}
		else
			printf("Invalid Action potential object key (0x%llx) encountered\n", (unsigned __int64)ap->id);
	}
	catch (...)
	{
		// ignore
	}
}

bool Global::validTimedEvent(unsigned long id)
{
	if (id >= componentBase[ComponentTypeTimedEvent] && id < componentBase[ComponentTypeTimedEvent] + 100000000)
		return true;
	return false;
}

bool Global::validActionPotential(unsigned long id)
{
	if (id >= componentBase[ComponentTypeActionPotential] && id < componentBase[ComponentTypeTimedEvent])
		return true;
	return false;
}
/*
size_t Global::removeTimedEvent(TimedEvent *te)
{
	size_t count = 0;
	boost::mutex::scoped_lock amx(timedevents_mutex);
	if (validTimedEvent(te->id))
	{
		count = allTimedEvents.erase(te->id);
		if(count>0)
		{
	//		std::cout << "deleting timed event " << te->id << std::endl;
			delete te;
		}
		return count;
	}
	return count;
}
*/

void Global::addTimedEvent(std::shared_ptr<TimedEvent> te)
{
	boost::mutex::scoped_lock amx(timedevents_mutex);
	allTimedEvents[te->id] = te;
	// allTimedEvents.insert(std::pair<long,TimedEvent *>(te->id,te));
}

void Global::addAP(ActionPotential *ap)
{
	boost::mutex::scoped_lock amx(actionpotential_mutex);
	globalInsert(ap);
	//actionpotentials.insert(std::pair<long, ActionPotential *>(ap->id, ap));
}
/*
void Global::removeDeadAPs(void)
{
	std::vector<long> finishedList;

	boost::mutex::scoped_lock amx(actionpotential_mutex);
	//	std::map<long,ActionPotential *>::iterator it = globalObject->actionpotentials.begin();
	for (std::map<long, ActionPotential *>::iterator it = globalObject->actionpotentials.begin(); it != globalObject->actionpotentials.end(); ++it)
	{
		ActionPotential *ap = it->second;
		finishedList.push_back(ap->id);
	}
	for (size_t i = 0; i < finishedList.size(); i++)
	{
		long key = finishedList[i];
		ActionPotential *ap = actionpotentials[key];
		//globalObject->removeAPNoMux(ap);
		//		globalObject->actionpotentials.erase(ap->id);
		//		delete ap;
	}
	finishedList.clear();
	//	std::map<long,Neuron *>::iterator it2 = globalObject->firingNeurons.begin();
	boost::mutex::scoped_lock amx2(firingNeurons_mutex);
	for (std::map<long, Neuron *>::iterator it2 = globalObject->firingNeurons.begin(); it2 != globalObject->firingNeurons.end(); ++it2)
	{
		Neuron *n = it2->second;
		if (n != NULL)
		{
			if (n->isFiring() && ((globalObject->current_timestep - n->getLastFired()) > REFACTORY_PERIOD))
			{
				finishedList.push_back(n->id);
			}
		}
	}
	for (size_t i = 0; i < finishedList.size(); i++)
	{
		long key = finishedList[i];
		Neuron *n = firingNeurons[key];
		if (n != NULL)
		{
			n->setFiring(false);
			//		std::cout << "Neuron " << n->id << " ceased firing" << std::endl;
			globalObject->firingNeurons.erase(n->id);
		}
	}
	//	std::cout << "Current AP count " << globalObject->actionpotentials.size() << "." << std::endl;
}
*/

void Global::insert(Brain *brain)
{
	brainDB.insert(brain);
}

size_t Global::brainSize(void)
{
	return brainDB.size();
};

// std::map<long,Brain *> *Global::getBrainsCollection(void)
//{
//	return &globalObject->brains;
// }

// std::map<long,Region *> *Global::getRegionsCollection(void)
//{
//	return &globalObject->regions;
// }

void Global::insert(Region *region)
{
	regionDB.insert(region);
}

size_t Global::regionsSize(void)
{
	return regionDB.size();
};

// std::map<long,Nucleus *> *Global::getNucleiCollection(void)
//{
//	return &globalObject->nuclei;
// }

void Global::insert(Nucleus *nucleus)
{
	nucleusDB.insert(nucleus);
}

size_t Global::nucleiSize(void)
{
	return nucleusDB.size();
};

// std::map<long,Column *> *Global::getColumnsCollection(void)
//{
//	return &globalObject->columns;
// }

void Global::insert(Column *column)
{
	columnDB.insert(column);
}

size_t Global::columnsSize(void)
{
	return columnDB.size();
};

// std::map<long,Layer *> *Global::getLayersCollection(void)
//{
//	return &globalObject->layers;
// }

void Global::insert(Layer *layer)
{
	layerDB.insert(layer);
}

size_t Global::layersSize(void)
{
	return layerDB.size();
};

// std::map<long,Cluster *> *Global::getClustersCollection(void)
//{
//	return &globalObject->clusters;
// }

void Global::insert(Cluster *cluster)
{
	clusterDB.insert(cluster);
}

size_t Global::clustersSize(void)
{
	return clusterDB.size();
};
/*
std::map<long,Neuron *> *Global::getNeuronsCollection(void)
{
	return &globalObject->neurons;
}
*/
void Global::insert(Neuron *neuron)
{
	//	neurons.insert(std::pair<long,Neuron *>(neuron->id,neap->id,uron));
	neuronDB.insert(neuron);
}

size_t Global::neuronsSize(void)
{
	//	return neurons.size();
	return neuronDB.size();
};

// std::map<long,Axon *> *Global::getAxonsCollection(void)
//{
//	return &globalObject->axons;
// }

void Global::insert(Axon *axon)
{
	axonDB.insert(axon);
	//	axons.insert(std::pair<long,Axon *>(axon->id,axon));
}

size_t Global::axonsSize(void)
{
	return axonDB.size();
	// return axons.size();
};

// std::map<long,Dendrite *> *Global::getDendritesCollection(void)
//{
//	return &globalObject->dendrites;
// }

void Global::insert(Dendrite *dendrite)
{
	dendriteDB.insert(dendrite);
	//	dendrites.insert(std::pair<long,Dendrite *>(dendrite->id,dendrite));
}

size_t Global::dendritesSize(void)
{
	return dendriteDB.size();
	//	return dendrites.size();
};

// std::map<long,Synapse *> *Global::getSynapsesCollection(void)
//{
//	return &globalObject->synapses;
// }

void Global::insert(Synapse *synapse)
{
	synapseDB.insert(synapse);
	//	synapses.insert(std::pair<long,Synapse *>(synapse->id,synapse));
}

size_t Global::synapsesSize(void)
{
	return synapseDB.size();
	//	return synapses.size();
};

// std::map<long,ActionPotential *> *Global::getActionPotentialsCollection(void)
//{
//	return &globalObject->actionpotentials;
// }

std::vector<long> *Global::getActionPotentialKeysCollection(void)
{
	boost::mutex::scoped_lock amx(actionpotential_mutex);

	std::vector<long> *keys = new std::vector<long>();
	std::map<long, ActionPotential *>::iterator it;
	for (it = actionpotentials.begin(); it != actionpotentials.end(); ++it)
	{
		long key = it->first;
		keys->push_back(key);
	}

	return keys;
}

ActionPotential *Global::getActionPotential(long id)
{
	boost::mutex::scoped_lock amx(actionpotential_mutex);
	return actionpotentials[id];
}

void Global::globalInsert(ActionPotential *actionPotential)
{
	actionpotentials.insert(std::pair<long, ActionPotential *>(actionPotential->id, actionPotential));
}

size_t Global::actionPotentialsSize(void)
{
	return actionpotentials.size();
};

void Global::insertFiring(Neuron *neuron)
{
	boost::mutex::scoped_lock amx(firingNeurons_mutex);
	firingNeurons.insert(std::pair<long, Neuron *>(neuron->id, neuron));
}

std::vector<std::shared_ptr<TimedEvent>>* Global::getTimedEventCollection(void)
{
    size_t intervalOffsetValue = globalObject->current_timestep % MAX_TIMEINTERVAL_BUFFER_SIZE;
    return &globalObject->timeIntervalEvents[intervalOffsetValue];
}

bool Global::componentKeyInRange(unsigned long key)
{

	if (key >= componentBase[ComponentTypeBrain] && key < (componentBase[ComponentTypeTimedEvent] + 100000000))
	{
		return true;
	}
	return false;
}

void Global::insert(TimedEvent *timedEvent, int intervalOffset)
{
	size_t intervalOffsetValue = (current_timestep + intervalOffset) % MAX_TIMEINTERVAL_BUFFER_SIZE;

	unsigned long apId = timedEvent->apId;
	if (componentKeyInRange(apId))
	{
		if (intervalOffset > MAX_TIMEINTERVAL_BUFFER_SIZE)
		{
			std::stringstream ss;
			LOGSTREAM(ss) << "Interval Offset of " << intervalOffset << " exceeds max interval buffer size. Event ignored" << std::endl;
			globalObject->log(ss);
		}
		else
		{
			if (intervalOffset < 0)
			{
				std::stringstream ss;
				LOGSTREAM(ss) << "Interval Offset of " << intervalOffset << " is invalid (negative). Event ignored" << std::endl;
				globalObject->log(ss);
				return;
			}

 			// Take ownership of timedEvent using shared_ptr
            std::shared_ptr<TimedEvent> eventPtr(timedEvent);

            // Access the vector via smart pointers
            std::vector<std::shared_ptr<TimedEvent>>* teVector = &globalObject->timeIntervalEvents[intervalOffsetValue];

            // Lock the corresponding mutex before modifying the vector
            boost::mutex::scoped_lock amx(*teVector_mutex[intervalOffsetValue]);

            // Insert the shared_ptr into the vector (transferring ownership)
            teVector->push_back(std::move(eventPtr));

 //           addTimedEvent(std::move(eventPtr));
            // std::cout << "Inserting event " << timedEvent->id << " offset " << intervalOffset << " at intervalOffsetValue " << intervalOffsetValue << std::endl;
		}
	}
	else
	{
		std::cout << "Invalid AP while Inserting timed event " << timedEvent->id << " offset " << intervalOffset << " at intervaloffsetvalue " << intervalOffsetValue << std::endl;
	}
}
/*
void Global::launchBatch(std::vector<TimedEvent *> *teVector, int tevSize, size_t intervalOffsetValue)
{

	int sizeper = tevSize / MAX_THREADPOOL_SIZE;
	boost::asio::thread_pool workers(MAX_THREADPOOL_SIZE);

	for (int n = 0; n < MAX_THREADPOOL_SIZE; ++n)
	{
		boost::asio::post(workers, [&]
						  { cycleSlice(teVector, n * sizeper, sizeper, false, intervalOffsetValue); });
	}
	// workers.join();
}
*/

size_t Global::timedEventSize(void)
{
    size_t intervalOffsetValue = current_timestep % MAX_TIMEINTERVAL_BUFFER_SIZE;
    // Lock the corresponding mutex before accessing the vector
    boost::mutex::scoped_lock amx(*teVector_mutex[intervalOffsetValue]);

    // Access the vector as a vector of std::shared_ptr<TimedEvent>
    std::vector<std::shared_ptr<TimedEvent>>* teVector = &globalObject->timeIntervalEvents[intervalOffsetValue];
    return teVector->size();
}

// Cycle through all timed events within this timestep
// TODO: This method needs to be reworked to take advantage of multiple threads

void doCycle(void)
{
	globalObject->runCycle();
}

/// @brief
/// @param
void Global::cycle(void)
{
	runCycle();
	// boost::thread workerThread(&Global::runCycle, this);
	//	boost::asio::thread_pool workers; // MAX_THREADPOOL_SIZE threads for now
	// boost::asio::post(*workers, [=] 	{ runCycle(); });
	// boost::thread t(&doCycle);
}

void Global::runCycle(void)
{
    size_t intervalOffsetValue = current_timestep % MAX_TIMEINTERVAL_BUFFER_SIZE;
    int tevSize = (int)timedEventSize();

    if (tevSize > 0)
    {
        // Now using smart pointers in getTimedEventCollection
        std::vector<std::shared_ptr<TimedEvent>> *teVector = getTimedEventCollection();
        std::shared_ptr<std::pair<std::vector<std::shared_ptr<Tuple>>, std::vector<std::shared_ptr<Tuple>>>> spikes = getSpikes(10L); // Get spikes within 10 ms

        if (tevSize > THREADPOOL_SLICE_THRESHOLD)
        {
            // If the number of events exceeds the threshold, process them in slices
            int sizePer = tevSize / MAX_THREADPOOL_SIZE;
            std::cout << "Split " << MAX_THREADPOOL_SIZE << " slices of " << sizePer << " each...";

            for (int n = 0; n < MAX_THREADPOOL_SIZE; ++n)
            {
                boost::asio::post(*workers, [&, n, sizePer]
                                  { cycleSlice(teVector, n * sizePer, sizePer, false, intervalOffsetValue, std::move(spikes)); });
            }
            workers->join();

            std::cout << "Slices ended" << std::endl;
        }
        else
        {
            // If below threshold, process all events at once
            cycleSlice(teVector, 0, tevSize, false, intervalOffsetValue, std::move(spikes));

            std::vector<std::shared_ptr<TimedEvent>> *backupTeVector = &backupTimeIntervalEvents[intervalOffsetValue];
            size_t bvSize = backupTeVector->size();
            size_t allCount = allTimedEvents.size();

            // Move all events from this timeslice into the backupVector
            for (size_t i = 0; i < tevSize; i++)
            {
                // Moving smart pointers between vectors
                backupTeVector->push_back(std::move((*teVector)[i]));
            }
            teVector->clear(); // Empty the timeslice vector

            // Additional code for processing removed events can be adapted here using smart pointers
        }
    }
}


/*
size_t Global::removeExpiredEvents()
{
	size_t eventsRemovedCount = 0;
	size_t allEventCount = allTimedEvents.size();

	long cutoffSlice = globalObject->current_timestep - MAX_TIMEINTERVAL_BUFFER_SIZE;

	std::vector<TimedEvent *> events;
	for (auto it = allTimedEvents.begin(); it != allTimedEvents.end(); ++it)
	{
		TimedEvent *te = it->second;
		if (te != NULL)
		{
			if (te->slice < cutoffSlice)
			{
				events.push_back(te);
			}
		}
	}
	for (size_t i = 0; i < events.size(); i++)
	{
		TimedEvent *te = events[i];
		unsigned long apId = te->apId;
		if (validActionPotential(apId))
		{
			if (actionpotentials.find(apId) != actionpotentials.end())
			{
				ActionPotential *ap = actionpotentials[apId];
				removeAP(ap);
			}
		}
		removeTimedEvent(te);
		eventsRemovedCount++;
	}

	//	std::cout << "AllEvents in: " << allEventCount << " out " << eventsRemovedCount << std::endl;

	return eventsRemovedCount;
}
*/

void Global::cycleSlice(std::vector<std::shared_ptr<TimedEvent>> *teVector, size_t start, size_t count, bool display, size_t intervalOffsetValue, std::shared_ptr<std::pair<std::vector<std::shared_ptr<Tuple>>, std::vector<std::shared_ptr<Tuple>>>> spikes)
{
    for (size_t i = start; i < start + count; i++)
    {
        TimedEvent* te = (*teVector)[i].get();  // Use get() to access the underlying pointer from shared_ptr
        unsigned long apId = te->apId;
        if (validActionPotential(apId))
        {
            auto it = actionpotentials.find(apId);
            if (it != actionpotentials.end())
            {
                ActionPotential* ap = it->second;  // Direct access to the raw pointer

                if (ap->owningProcessId >= globalObject->componentBase[ComponentTypeAxon] && ap->owningProcessId < globalObject->componentBase[ComponentTypeSynapse])
                {
                    if (ap->owningProcessId < globalObject->componentBase[ComponentTypeDendrite])  // If < dendrite range, handle as axon
                    {
                        Synapse* s = globalObject->synapseDB.getComponent(te->synapseId);
                        s->receiveAP(ap);  // Passing raw pointer
                    }
                    else
                    {
                        Dendrite* dendrite = globalObject->dendriteDB.getComponent(ap->owningProcessId);  // Handle as dendrite
                        dendrite->neuronAdjust(ap, std::move(spikes));  // Adjust the spikes handling
                    }
                }
                else
                {
                    std::cerr << "cycleSlice(): Error item: " << std::hex << ap->owningProcessId << "(" << ap->owningProcessId << ") owning process " << std::hex << ap->id << " not an axon or dendrite in cycleSlice()\n";
                }
            }
        }
    }

    if (display)
        printf("slice (%d - %d) complete.\n", (int)start, (int)count);
}

/*
void Global::tagDeadAPs(void)
{

	bool done = false;
	while(!done)
	{
		done = true;
		std::map<long,ActionPotential *>::iterator it = globalObject->actionpotentials.begin();
		for (it=globalObject->actionpotentials.begin(); it!=globalObject->actionpotentials.end(); ++it)
		{
			ActionPotential *ap = it->second;
			bool apFound = false;
			for(size_t i=0;i<MAX_TIMEINTERVAL_BUFFER_SIZE;i++)
			{
				std::vector<TimedEvent *> *teVector = &globalObject->timeIntervalEvents[i];
				size_t sz = teVector->size();
				if(sz>0)
				{
					for(size_t j=0;j<sz;j++)
					{
						TimedEvent *te = (*teVector)[j];
						if(te->ap->id == ap->id)
						{
							apFound = true;
							break;
						}
					}
				}
			}
			if(!apFound)
				ap->finished = true;
		}
	}
}
*/

void Global::flush(void)
{
	layerDB.flush();
	clusterDB.flush();
	columnDB.flush();
	nucleusDB.flush();
	regionDB.flush();
	brainDB.flush();
	neuronDB.flush();
	axonDB.flush();
	dendriteDB.flush();
	synapseDB.flush();
}

void Global::flushAll(void)
{
	layerDB.flushAll();
	clusterDB.flushAll();
	columnDB.flushAll();
	nucleusDB.flushAll();
	regionDB.flushAll();
	brainDB.flushAll();
	neuronDB.flushAll();
	axonDB.flushAll();
	dendriteDB.flushAll();
	synapseDB.flushAll();
}

void Global::loadAll(void)
{
	layerDB.loadCache();
	clusterDB.loadCache();
	columnDB.loadCache();
	nucleusDB.loadCache();
	regionDB.loadCache();
	brainDB.loadCache();
	neuronDB.loadCache();
	axonDB.loadCache();
	dendriteDB.loadCache();
	synapseDB.loadCache();
}

void Global::shutdown(void)
{

	std::cerr << "Shutting down: clearing remaining APs" << std::endl;

	std::vector<long> actionpotentialIds;
	std::map<long, ActionPotential *>::iterator it;
	for (it = actionpotentials.begin(); it != globalObject->actionpotentials.end(); ++it)
	{
		ActionPotential *ap = it->second;
		removeAP(ap);
		//		actionpotentialIds.push_back(it->first);
	}

	std::cerr << "Shutting down: Stopping databases" << std::endl;

	layerDB.shutdown();
	clusterDB.shutdown();
	columnDB.shutdown();
	nucleusDB.shutdown();
	regionDB.shutdown();
	brainDB.shutdown();
	neuronDB.shutdown();
	axonDB.shutdown();
	dendriteDB.shutdown();
	synapseDB.shutdown();

	/*
		std::cerr << "Shutting down: clearing remaining TimedEvents" << std::endl;

		for(size_t i=0;i<MAX_TIMEINTERVAL_BUFFER_SIZE;i++)
		{
			std::vector<TimedEvent *> *tev = &timeIntervalEvents[i];
			size_t teSize = tev->size();
			for(size_t k=0;k<teSize;k++)
			{
				delete (*tev)[k];
			}
		}
	*/
}

void Global::debug(char *str)
{
	boost::mutex::scoped_lock amx(debug_mutex);

	time_t rawtime;
	struct tm *timeinfo;
	char buffer[80];

	time(&rawtime);
	timeinfo = localtime(&rawtime);

	strftime(buffer, 80, "%d-%m-%Y %I:%M:%S", timeinfo);
	std::string timestr(buffer);

	std::string s(str);

	if (debugfile == NULL)
	{
		std::string filename(std::string(DB_PATH) + BRAINDEMONAME + std::string("/") + std::string("debug.txt"));
		debugfile = new std::ofstream(filename, std::ios::out);
	}
	*debugfile << timestr << " : " << s << std::endl;
}

void Global::debug(std::stringstream &ss)
{
	debug((char *)ss.str().c_str());
}

void Global::log(char *str)
{
	time_t rawtime;
	struct tm *timeinfo;
	char buffer[80];

	time(&rawtime);
	timeinfo = localtime(&rawtime);

	strftime(buffer, 80, "%d-%m-%Y %I:%M:%S", timeinfo);
	std::string timestr(buffer);

	std::string s(str);
	std::cout << timestr << " : " << s;

	std::ofstream logfile;
	logfile.open(std::string(DB_PATH) + BRAINDEMONAME + std::string("/") + "logfile.txt", std::ios::app);
	logfile << timestr << " : " << s;
	logfile.close();
}

void Global::log(std::stringstream &ss)
{
	log((char *)ss.str().c_str());
}

void Global::writeSyncpoint(int sp)
{

	time_t rawtime;
	struct tm *timeinfo;
	char buffer[80];

	time(&rawtime);
	timeinfo = localtime(&rawtime);

	strftime(buffer, 80, "%d-%m-%Y %I:%M:%S", timeinfo);
	std::string timestr(buffer);

	std::ofstream spfile;
	spfile.open(std::string(DB_PATH) + BRAINDEMONAME + std::string("/") + "syncpoint.txt", std::ios::trunc);
	spfile << timestr << " | syncpoint " << " = " << sp << std::endl;

	for (size_t i = 0; i < CTYPE_COUNT; i++)
	{
		long thisCount = 0;
		switch (i)
		{
			//	1 = ComponentDB<Brain> brainDB;
		case 1:
			thisCount = (long)globalObject->brainDB.size();
			spfile << timestr << " | brain " << " = " << thisCount << std::endl;
			break;
			//	2 = ComponentDB<Region> regionDB;
		case 2:
			thisCount = (long)globalObject->regionDB.size();
			spfile << timestr << " | region " << " = " << thisCount << std::endl;
			break;
			//	3 = ComponentDB<Nucleus> nucleusDB;
		case 3:
			thisCount = (long)globalObject->nucleusDB.size();
			spfile << timestr << " | nucleus " << " = " << thisCount << std::endl;
			break;
			//	4 = ComponentDB<Column> columnDB;
		case 4:
			thisCount = (long)globalObject->columnDB.size();
			spfile << timestr << " | column " << " = " << thisCount << std::endl;
			break;
			//	5 = ComponentDB<Layer> layerDB;
		case 5:
			thisCount = (long)globalObject->layerDB.size();
			spfile << timestr << " | layer " << " = " << thisCount << std::endl;
			break;
			//	6 = ComponentDB<Cluster> clusterDB;
		case 6:
			thisCount = (long)globalObject->clusterDB.size();
			spfile << timestr << " | cluster " << " = " << thisCount << std::endl;
			break;
			//	7 = ComponentDB<Neuron> neuronDB;
		case 7:
			thisCount = (long)globalObject->neuronDB.size();
			spfile << timestr << " | neuron " << " = " << thisCount << std::endl;
			break;
			//	8 = ComponentDB<Axon> axonDB;
		case 8:
			thisCount = (long)globalObject->axonDB.size();
			spfile << timestr << " | axon " << " = " << thisCount << std::endl;
			break;
			//	9 = ComponentDB<Dendrite> dendriteDB;
		case 9:
			thisCount = (long)globalObject->dendriteDB.size();
			spfile << timestr << " | dendrite " << " = " << thisCount << std::endl;
			break;
			//	10 = ComponentDB<Synapse> synapseDB;
		case 10:
			thisCount = (long)globalObject->synapseDB.size();
			spfile << timestr << " | synapse " << " = " << thisCount << std::endl;
			break;
		default:
			break;
		}
	}
	spfile.close();
}

int Global::readSyncpoint(void)
{
	std::string line;
	std::string delimiter1 = "|";
	std::string delimiter2 = "=";
	std::ifstream spfile;
	spfile.open(std::string(DB_PATH) + BRAINDEMONAME + std::string("/") + "syncpoint.txt", std::ios::in);
	while (std::getline(spfile, line))
	{
		std::string temp = line.substr(line.find(delimiter1) + 1);
		std::string sptoken1 = Global::trim(temp);
		size_t pos = sptoken1.find(delimiter2);
		temp = sptoken1.substr(0, pos);
		std::string sptokenKey = Global::trim(temp);
		temp = sptoken1.substr(pos + 1);
		std::string sptokenValue = Global::trim(temp);
		int value = (size_t)atoi(sptokenValue.c_str());

		if (sptokenKey == "syncpoint")
			syncpoint = value;
		//	1 = ComponentDB<Brain> brainDB;
		if (sptokenKey == "brain")
			globalObject->brainDB.componentCount = (size_t)value;
		//	2 = ComponentDB<Region> regionDB;
		if (sptokenKey == "region")
			globalObject->regionDB.componentCount = (size_t)value;
		//	3 = ComponentDB<Nucleus> nucleusDB;
		if (sptokenKey == "nucleus")
			globalObject->nucleusDB.componentCount = (size_t)value;
		//	4 = ComponentDB<Column> columnDB;
		if (sptokenKey == "column")
			globalObject->columnDB.componentCount = (size_t)value;
		//	5 = ComponentDB<Layer> layerDB;
		if (sptokenKey == "layer")
			globalObject->layerDB.componentCount = (size_t)value;
		//	6 = ComponentDB<Cluster> clusterDB;
		if (sptokenKey == "cluster")
			globalObject->clusterDB.componentCount = (size_t)value;
		//	7 = ComponentDB<Neuron> neuronDB;
		if (sptokenKey == "neuron")
			globalObject->neuronDB.componentCount = (size_t)value;
		//	8 = ComponentDB<Axon> axonDB;
		if (sptokenKey == "axon")
			globalObject->axonDB.componentCount = (size_t)value;
		//	9 = ComponentDB<Dendrite> dendriteDB;
		if (sptokenKey == "dendrite")
			globalObject->dendriteDB.componentCount = (size_t)value;
		//	10 = ComponentDB<Synapse> synapseDB;
		if (sptokenKey == "synapse")
			globalObject->synapseDB.componentCount = (size_t)value;
	}

	spfile.close();

	return syncpoint;
}

void Global::logFiring(Neuron *n, bool fireStatus)
{

	int intStat = (fireStatus) ? 1 : 0;
	std::stringstream msg;

	if (globalObject->setLogFiring)
	{
		msg << current_timestep << ": Neuron" << " " << n->id << ", state " << intStat << ", threshold " << n->threshold << ",  potential" << n->potential << std::endl;
		writeFireLog(msg.str().c_str());
	}
}

long getGlobalTimestep()
{
	return globalObject->current_timestep;
}

boost::mutex xThreadQueue_mutex;
std::queue<std::string> threadQueue;

std::string Global::getMessage(void)
{
	boost::mutex::scoped_lock mx(xThreadQueue_mutex);
	std::string msg;
	if (!xThreadQueue.empty())
	{
		msg = xThreadQueue.front();
		xThreadQueue.pop();
	}
	return msg;
}

void Global::putMessage(std::string msg)
{
	boost::mutex::scoped_lock mx(xThreadQueue_mutex);
	xThreadQueue.push(msg);
}

//void Global::stdp(Neuron *n, ActionPotential *ap, std::pair<std::vector<Tuple *> *, std::vector<Tuple *> *> *spikes) // Launch the STDP adjustments as background threads
//{
//	boost::mutex::scoped_lock amx(globalObject->stdp_mutex); // Ensure we only process one STDP calc at a time
//	globalObject->applySTDP(n, ap, spikes);
//}

void Global::applySTDP(Neuron *n, ActionPotential *ap, std::shared_ptr<std::pair<std::vector<std::shared_ptr<Tuple>>, std::vector<std::shared_ptr<Tuple>>>>  slices) // Launch the STDP adjustments as background threads
{
	// boost::thread workerThread(&Global::stdp, n, ap);
	n->applySTDP(ap, std::move(slices));
}

std::shared_ptr<std::pair<std::vector<std::shared_ptr<Tuple>>, std::vector<std::shared_ptr<Tuple>>>> Global::getSpikes(long interval)
{
    auto preSpikeTimes = std::make_unique<std::vector<std::shared_ptr<Tuple>>>();
    auto postSpikeTimes = std::make_unique<std::vector<std::shared_ptr<Tuple>>>();

    boost::mutex::scoped_lock amx(timedevents_mutex);

    int beginning_timestamp = globalObject->current_timestep - interval;
    int ending_timestamp = globalObject->current_timestep + interval;

    for (int thisInterval = beginning_timestamp; thisInterval < ending_timestamp; thisInterval++)
    {
        int thisIndex = thisInterval % MAX_TIMEINTERVAL_BUFFER_SIZE;
        int numEvents = timeIntervalEvents[thisIndex].size();
        for (int teIndex = 0; teIndex < numEvents; teIndex++)
        {
            std::shared_ptr<TimedEvent>& te = timeIntervalEvents[thisIndex][teIndex];
            if (thisInterval < globalObject->current_timestep)
            {
                auto t = std::make_unique<Tuple>();
                t->objectPtr = reinterpret_cast<char *>(te.get());
                t->value = te->slice;
                preSpikeTimes->push_back(std::move(t));
            }
            else if (thisInterval >= globalObject->current_timestep)
            {
                auto t = std::make_unique<Tuple>();
                t->objectPtr = reinterpret_cast<char *>(te.get());
                t->value = te->slice;
                postSpikeTimes->push_back(std::move(t));
            }
        }
    }

    auto retpair = std::make_unique<std::pair<std::vector<std::shared_ptr<Tuple>>, std::vector<std::shared_ptr<Tuple>>>>(std::move(*preSpikeTimes), std::move(*postSpikeTimes));

    return retpair;
}


void Global::writeFireLog(std::string msg)
{

	if (firelogfile == NULL)
	{
		firelogfile = new std::ofstream(std::string(DB_PATH) + BRAINDEMONAME + std::string("/") + "fireLog.txt", std::ios::app);
	}
	*firelogfile << msg << std::endl;
}

void Global::closeFireLog(void)
{

	if (firelogfile != NULL)
	{
		firelogfile->close();
	}
}

void Global::closeDebugLog(void)
{

	if (debugfile != NULL)
	{
		debugfile->close();
	}
}

std::vector<float> Global::softmax(const std::vector<float> &input)
{
	std::vector<float> exponentials(input.size());
	std::transform(input.begin(), input.end(), exponentials.begin(), [](float value)
				   { return std::exp(value); });

	float sum = std::accumulate(exponentials.begin(), exponentials.end(), 0.0f);
	std::vector<float> softmaxVector(input.size());

	if (sum != 0)
	{ // Check to prevent division by zero
		std::transform(exponentials.begin(), exponentials.end(), softmaxVector.begin(), [sum](float value)
					   { return value / sum; });
	}

	return softmaxVector;
}
