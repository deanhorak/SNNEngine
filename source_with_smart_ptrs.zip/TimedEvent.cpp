#include "TimedEvent.h"
#include "Global.h"

TimedEvent::TimedEvent(long timeSlice):
	NNComponent(ComponentTypeTimedEvent)
{
	slice = timeSlice;
	apId = 0;
	id = globalObject->nextComponent(ComponentTypeTimedEvent);
}

TimedEvent::~TimedEvent(void)
{
	//std::cout << "destructing timed event " << id << std::endl;
}

TimedEvent *TimedEvent::create(long timeSlice, ActionPotential* ap, long synapseId)
{
	TimedEvent *te = new TimedEvent(timeSlice);
	te->apId = ap->id;
	te->synapseId = synapseId;
	return te;
}
