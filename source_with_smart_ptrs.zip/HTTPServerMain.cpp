#include "HTTPServerMain.h"

#include <sys/resource.h>
#include <sys/time.h>
#include <math.h>

#include <cerrno>
#include <chrono>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string>
#include <thread>

#include "HTTPMessage.h"
#include "HTTPServer.h"
#include "uri.h"
#include "Global.h"

#include "nlohmann/json.hpp"
#include <boost/algorithm/string.hpp>

using simple_http_server::HttpMethod;
using simple_http_server::HttpRequest;
using simple_http_server::HttpResponse;
using simple_http_server::HttpServer;
using simple_http_server::HttpStatusCode;

unsigned char bitmapper[8] = {128, 64, 32, 16, 8, 4, 2, 1};
//unsigned char andbitmapper[8] = {127, 191, 223, 239, 247, 251, 253, 254};

static const std::string base64_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

std::string convertBitmapToString(unsigned char *buffer, size_t bitlength)
{
  std::string retString;
  for(int i=0;i<bitlength;i++)
  {
    int byteindex = i / 8;
    int bitindex = i % 8;
    unsigned char value = *(buffer + i) & bitmapper[bitindex];
    if(value == '\0')
      retString += "0";
    else 
      retString += "1";
  }
  return retString;
}

std::string base64_encode(unsigned char const *bytes_to_encode, unsigned int in_len)
{
  std::string ret;
  int i = 0;
  int j = 0;
  unsigned char char_array_3[3];
  unsigned char char_array_4[4];

  while (in_len--)
  {
    char_array_3[i++] = *(bytes_to_encode++);
    if (i == 3)
    {
      char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
      char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
      char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
      char_array_4[3] = char_array_3[2] & 0x3f;

      for (i = 0; (i < 4); i++)
        ret += base64_chars[char_array_4[i]];
      i = 0;
    }
  }

  if (i)
  {
    for (j = i; j < 3; j++)
      char_array_3[j] = '\0';

    char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
    char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
    char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
    char_array_4[3] = char_array_3[2] & 0x3f;

    for (j = 0; (j < i + 1); j++)
      ret += base64_chars[char_array_4[j]];

    while ((i++ < 3))
      ret += '=';
  }

  return ret;
}

static inline bool is_base64(unsigned char c)
{
  return (isalnum(c) || (c == '+') || (c == '/'));
}

unsigned char* base64_decode(const std::string& encoded_string, size_t* out_len) {
    size_t in_len = encoded_string.size();
    size_t padding = 0;

    // Remove any padding characters ('=')
    while (in_len > 0 && encoded_string[in_len - 1] == '=')
        padding++, in_len--;

    // Calculate the output buffer size
    size_t out_size = (in_len * 3) / 4;
    if (padding > 0)
        out_size -= padding;

    // Allocate memory for the output buffer
    unsigned char* buffer = new unsigned char[out_size];

    size_t i = 0, j = 0;
    unsigned char char_array_4[4], char_array_3[3];

    while (i < in_len) {
        // Decode 4 base64 characters to 3 bytes
        for (size_t k = 0; k < 4; k++) {
            char_array_4[k] = base64_chars.find(encoded_string[i]) & 0xFF;
            i++;
        }

        char_array_3[0] = (char_array_4[0] << 2) | (char_array_4[1] >> 4);
        char_array_3[1] = (char_array_4[1] << 4) | (char_array_4[2] >> 2);
        char_array_3[2] = (char_array_4[2] << 6) | char_array_4[3];

        for (size_t k = 0; k < 3; k++) {
            if (j < out_size)
                buffer[j++] = char_array_3[k];
        }
    }

    // Set the output length
    *out_len = out_size+1;
    return buffer;
}

void ensure_enough_resource(int resource, std::uint32_t soft_limit,
                            std::uint32_t hard_limit)
{
  rlimit new_limit, old_limit;

  new_limit.rlim_cur = soft_limit;
  new_limit.rlim_max = hard_limit;
  getrlimit(resource, &old_limit);

  std::cout << "Old limit: " << old_limit.rlim_cur << " (soft limit), "
            << old_limit.rlim_cur << " (hard limit)." << std::endl;
  std::cout << "New limit: " << new_limit.rlim_cur << " (soft limit), "
            << new_limit.rlim_cur << " (hard limit)." << std::endl;

  if (setrlimit(resource, &new_limit))
  {
    std::cerr << "Warning: Could not update resource limit ";
    std::cerr << "(" << strerror(errno) << ")." << std::endl;
    std::cerr << "Consider setting the limit manually with ulimit" << std::endl;
    exit(-1);
  }
}

size_t min(size_t a, size_t b)
{
  return (a < b) ? a : b;
}

std::string parseAndRespond(std::string content)
{
  // get number of APs

  std::stringstream response;

  //size_t apCount = 0;
	//for (typename std::map<long, TimedEvent*>::iterator timedEventIterator = globalObject->allTimedEvents.begin(); timedEventIterator != globalObject->allTimedEvents.end(); ++timedEventIterator)
	//{
    		//TimedEvent* te = timedEventIterator->second;
        //ActionPotential *ap = te->ap;
  //      apCount++;
  //}

	//	std::vector<TimedEvent*>* teVector = globalObject->getTimedEventCollection();

  response << "<h2>Timed Events</h2>";

  response << "<p>" << globalObject->allTimedEvents.size() << " total timed events" << "<p>";

for(size_t i = 0; i < MAX_TIMEINTERVAL_BUFFER_SIZE; i++) {
    size_t intervalOffsetValue = (globalObject->current_timestep + i) % MAX_TIMEINTERVAL_BUFFER_SIZE;
    auto& teVector = globalObject->timeIntervalEvents[intervalOffsetValue]; // Reference to avoid copying
    size_t sz = teVector.size();

    if(sz > 0)
        response << "<p>Interval " << i <<  ": " << sz << "<p>";
}
  



  return response.str();
}

std::string parseAndRespondJSON(std::string content)
{

  // printf("%s\n", content.c_str());
  nlohmann::json jsonObject = nlohmann::json::parse(content);

  std::string command = jsonObject["command"];

  int returnCode = 999;
  std::string returnMessage = "Unknown command received: " + command;

  if (!command.empty())
  {
    if (boost::iequals(command, "GETNEURONS"))
    {
      //
      returnCode = 998;
      returnMessage = "command not currently implemented: " + command;
    }
    else if (boost::iequals(command, "SETACTIVATION"))
    {
      //
      returnCode = 998;
      returnMessage = "command not currently implemented: " + command;
    }
    else if (boost::iequals(command, "GETACTIVATION"))
    {
      //
      returnCode = 998;
      returnMessage = "command not currently implemented: " + command;
    }
    else if (boost::iequals(command, "GETACTIVENEURONS"))
    {
      //
      returnCode = 998;
      returnMessage = "command not currently implemented: " + command;
    }
    else if (boost::iequals(command, "GETTESTRESPONSE"))
    {
      auto nuclei = jsonObject["nuclei"];
      if (nuclei.is_array())
      {
        auto inputElement = nuclei[0];
        auto outputElement = nuclei[1];

        std::string inputNucleus = inputElement["nucleus"];
        std::string outputNucleus = outputElement["nucleus"];

        std::string inputPattern = inputElement["pattern"];

        std::vector<long> neurons = Server::getNeurons(inputNucleus, 0); // Layer 1 = input
        size_t totalSize = neurons.size();

        size_t tempBufferSize = 0;
        unsigned char *tempBuffer = base64_decode(inputPattern, &tempBufferSize);

        size_t numbits = min(totalSize, tempBufferSize * 8);

        // We now have the vector of neurons to update and the bit pattern to update them with
        for (int i = 0; i < numbits; i++)
        {
          int byteindex = i / 8;
          int bitindex = i % 8; // get the modulus
          long neuronId = neurons[i];
          Neuron *neuron = globalObject->neuronDB.getComponent(neuronId);

          unsigned char value = *(tempBuffer + byteindex); // get value of byte
          value &= bitmapper[bitindex];

          if (value != 0)
          { // Turn on firing
            neuron->fire();
          }
        }

        //
        free(tempBuffer);


        // we have fired the stimulus. Lets give a few ms to allow the APs to propagate.
        usleep(5); // 5ms which is half the refactor period

        // Now lets return the results from the output neurons

        // std::string pattern("");
        std::string nucleus = outputNucleus;
        if (nucleus.empty())
        {
          returnCode = 500; // invalid object reference
          returnMessage = "invalid object reference";
          std::string returnString = "{ \"Returncode\": \"" + std::to_string(returnCode) + "\", \"ReturnMessage\": \"" + returnMessage + "\" }";
          return returnString;
        }

        int totalFirings = 0;
        neurons = Server::getNeurons(nucleus, 5); // Layer 5 = output
        totalSize = neurons.size();

        tempBufferSize = totalSize / 8 + 1;

        tempBuffer = (unsigned char *)calloc(1, tempBufferSize);

        for (size_t i = 0; i < totalSize; i++)
        {
          long neuronId = neurons[i];
          Neuron *neuron = globalObject->neuronDB.getComponent(neuronId);
          int byteindex = i / 8;
          int bitindex = i % 8; // get the modulus

          if (neuron != NULL)
          {
            if (neuron->isFiring())
            {
              totalFirings++;
              *(tempBuffer + byteindex) |= bitmapper[bitindex]; // OR the byte to set the particular bit on
            }
          }
        }
        // tempBuffer now contains the activations in binary (on bit indicates neuron is firing)

        // printf("Response: %s\n",convertBitmapToString(tempBuffer,totalSize).c_str());
        // convert the buffer into a base64 string
        std::string encoded = base64_encode(tempBuffer, tempBufferSize);
        // release the tempbuffer
        free(tempBuffer);


        // format the return json string

        std::stringstream st;

        st << "SUCCESS TotalFirings = " << totalFirings;

        returnCode = 0;
        returnMessage = st.str();

        if(totalFirings>0)
          printf("Total Firings = %d\n", totalFirings);

        std::string returnString("{ \"pattern\": \"");
        returnString += encoded;
        returnString += "\", \"Returncode\": \"" + std::to_string(returnCode) + "\", \"ReturnMessage\": \"" + returnMessage + "\" }";
        // printf("%s\n",returnString.c_str());
        return returnString;
      }
      else
      {
        returnCode = 997;
        returnMessage = "nuclei missing: " + command;
        std::string returnString = "{ \"Returncode\": \"" + std::to_string(returnCode) + "\", \"ReturnMessage\": \"" + returnMessage + "\" }";
        // printf("%s\n",returnString.c_str());
        return returnString;
      }
    }
    else if (boost::iequals(command, "SETACTIVATIONPATTERN"))
    {

      auto nuclei = jsonObject["nuclei"];
      if (nuclei.is_array())
      {
        for (const auto &element : nuclei)
        {

          std::string nucleus = element["nucleus"];

          // printf("processing nucleus %s\n", nucleus.c_str());

          std::string pattern = element["pattern"];

          std::vector<long> neurons = Server::getNeurons(nucleus, 0); // Layer 1 = input
          size_t totalSize = neurons.size();

          size_t tempBufferSize = 0;
          unsigned char *tempBuffer = base64_decode(pattern, &tempBufferSize);

          size_t numbits = min(totalSize, tempBufferSize * 8);

          // We now have the vector of neurons to update and the bit pattern to update them with
          for (int i = 0; i < numbits; i++)
          {
            int byteindex = i / 8;
            int bitindex = i % 8; // get the modulus
            long neuronId = neurons[i];
            Neuron *neuron = globalObject->neuronDB.getComponent(neuronId);

            unsigned char value = *(tempBuffer + byteindex); // get value of byte
            value &= bitmapper[bitindex];

            if (value != 0)
            { // Turn on firing
              neuron->fire();
            }
          }

          //
          free(tempBuffer);
        }

        returnCode = 0;
        returnMessage = "SUCCESS";
        std::string returnString = "{ \"Returncode\": \"" + std::to_string(returnCode) + "\", \"ReturnMessage\": \"" + returnMessage + "\" }";
        // printf("%s\n",returnString.c_str());
        return returnString;
      }
      else
      {
        returnCode = 997;
        returnMessage = "nuclei missing: " + command;
        std::string returnString = "{ \"Returncode\": \"" + std::to_string(returnCode) + "\", \"ReturnMessage\": \"" + returnMessage + "\" }";
        // printf("%s\n",returnString.c_str());
        return returnString;
      }
    }
    else if (boost::iequals(command, "GETACTIVATIONPATTERN"))
    {
      //
      // std::string pattern("");
      std::string nucleus = jsonObject["nucleus"];
      if (nucleus.empty())
      {
        returnCode = 500; // invalid object reference
        returnMessage = "invalid object reference";
        std::string returnString = "{ \"Returncode\": \"" + std::to_string(returnCode) + "\", \"ReturnMessage\": \"" + returnMessage + "\" }";
        return returnString;
      }

      std::vector<long> neurons = Server::getNeurons(nucleus, 5); // Layer 6 = output
      size_t totalSize = neurons.size();

      size_t tempBufferSize = totalSize / 8 + 1;

      unsigned char *tempBuffer = (unsigned char *)calloc(1, tempBufferSize);

      for (size_t i = 0; i < totalSize; i++)
      {
        long neuronId = neurons[i];
        Neuron *neuron = globalObject->neuronDB.getComponent(neuronId);
        int byteindex = i / 8;
        int bitindex = i % 8; // get the modulus

        if (neuron != NULL)
        {
          if (neuron->isFiring())
          {
            *(tempBuffer + byteindex) |= bitmapper[bitindex]; // OR the byte to set the particular bit on
          }
        }
      }
      // tempBuffer now contains the activations in binary (on bit indicates neuron is firing)
      // convert the buffer into a base64 string
      std::string encoded = base64_encode(tempBuffer, tempBufferSize);
      // release the tempbuffer
      free(tempBuffer);

      // format the return json string

      returnCode = 0;
      returnMessage = "SUCCESS";

      std::string returnString("{ \"pattern\": \"");
      returnString += encoded;
      returnString += "\", \"Returncode\": \"" + std::to_string(returnCode) + "\", \"ReturnMessage\": \"" + returnMessage + "\" }";
      // printf("%s\n",returnString.c_str());
      return returnString;
    }
    else if (boost::iequals(command, "STARTATOMIC"))
    {
      //
      std::string value = jsonObject["value"];

      if (boost::iequals(value, "TRUE"))
      {
      }
      else
      {
      }
      returnCode = 998;
      returnMessage = "command not currently implemented: " + command;
      std::string returnString = "{ \"Returncode\": \"" + std::to_string(returnCode) + "\", \"ReturnMessage\": \"" + returnMessage + "\" }";
      // printf("%s\n",returnString.c_str());
      return returnString;
    }
    else if (boost::iequals(command, "FLUSH"))
    {
      //
      std::cout << "FLUSH command received" << std::endl;
      globalObject->flush(); // flush all databases - persist all Databases to disc
      std::cout << "FLUSH complete." << std::endl;
      returnCode = 0;
      returnMessage = "SUCCESS";
      std::string returnString = "{ \"Returncode\": \"" + std::to_string(returnCode) + "\", \"ReturnMessage\": \"" + returnMessage + "\" }";
      // printf("%s\n",returnString.c_str());
      return returnString;
    }
    else if (boost::iequals(command, "REPORT"))
    {
      returnCode = 998;
      returnMessage = "command not currently implemented: " + command;
      std::string returnString = "{ \"Returncode\": \"" + std::to_string(returnCode) + "\", \"ReturnMessage\": \"" + returnMessage + "\" }";
      // printf("%s\n",returnString.c_str());
      return returnString;
    }
    else
    {
      returnCode = 999;
      returnMessage = "Unknown command received: " + command;

      std::string responseContent = "{ \"Returncode\": \"" + std::to_string(returnCode) + "\", \"ReturnMessage\": \"" + returnMessage + "\" }";

      return responseContent;
    }
  }
  else
  {
    returnCode = 997;
    returnMessage = "empty command received: " + command;

    std::string responseContent = "{ \"Returncode\": \"" + std::to_string(returnCode) + "\", \"ReturnMessage\": \"" + returnMessage + "\" }";

    return responseContent;
  }
}

std::string computeResponse(std::string content)
{

  std::string responseContent = parseAndRespondJSON(content);
  return responseContent;
}

std::string computeStatus(std::string content)
{

  std::string responseContent = parseAndRespond(content);
  return responseContent;
}

extern int main_process(Brain *brain)
{
  std::string host = "0.0.0.0";
  int port = 8124;
  HttpServer server(host, port);

  //

  // Register a few endpoints for demo and benchmarking
  //auto say_hello = [](const HttpRequest &request) -> HttpResponse
  //{
  //  HttpResponse response(HttpStatusCode::Ok);
  //  response.SetHeader("Content-Type", "text/plain");
  //  response.SetContent("Hello, world\n");
  //  return response;
  //};


  auto say_json = [](const HttpRequest &request) -> HttpResponse
  {
    HttpResponse response(HttpStatusCode::Created);
    response.SetHeader("Content-Type", "application/json");
    // Compute response
    std::string content = computeResponse(request.content());
    response.SetContent(content);
    return response;
  };

  //auto send_html = [](const HttpRequest &request) -> HttpResponse
  //{
  //  HttpResponse response(HttpStatusCode::Ok);
  //  std::string content;
  //  content += "<!doctype html>\n";
  //  content += "<html>\n<body>\n\n";
  //  content += "<h1>Hello, world in an Html page</h1>\n";
  //  content += "<p>A Paragraph</p>\n\n";
  //  content += "</body>\n</html>\n";
  //
  //  response.SetHeader("Content-Type", "text/html");
  //  response.SetContent(content);
  //  return response;
  //};

  auto send_status = [](const HttpRequest &request) -> HttpResponse
  {
    HttpResponse response(HttpStatusCode::Ok);
    std::string content;
    content += "<!doctype html>\n";
    content += "<html>\n<body>\n\n";
    content += "<h1>SNNEngine Status</h1>\n";
    content += computeStatus(request.content());
    content += "</body>\n</html>\n";

    response.SetHeader("Content-Type", "text/html");
    response.SetContent(content);
    return response;
  };

//  server.RegisterHttpRequestHandler("/", HttpMethod::HEAD, say_hello);
//  server.RegisterHttpRequestHandler("/", HttpMethod::GET, say_hello);
//  server.RegisterHttpRequestHandler("/hello.html", HttpMethod::HEAD, send_html);
//  server.RegisterHttpRequestHandler("/hello.html", HttpMethod::GET, send_html);
  server.RegisterHttpRequestHandler("/api/data", HttpMethod::POST, say_json);
  server.RegisterHttpRequestHandler("/status", HttpMethod::GET, send_status);

  try
  {
    // std::cout << "Setting new limits for file descriptor count.." <<
    // std::endl; ensure_enough_resource(RLIMIT_NOFILE, 15000, 15000);

    // std::cout << "Setting new limits for number of threads.." << std::endl;
    // ensure_enough_resource(RLIMIT_NPROC, 60000, 60000);

    std::cout << "Starting the web server on " << host << ":" << port << std::endl;
    server.Start();
    std::cout << "Server listening on " << host << ":" << port << std::endl;

    // std::cout << "Enter [quit] to stop the server" << std::endl;
    std::string command;
    while (globalObject->keepWebserverRunning)
    { // std::cin >> command, command != "quit") {
      std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    }
    std::cout << "Stopping the web server.." << std::endl;
    server.Stop();
    std::cout << "Server stopped" << std::endl;
  }
  catch (std::exception &e)
  {
    std::cerr << "An error occurred: " << e.what() << std::endl;
    return -1;
  }

  return 0;
}
