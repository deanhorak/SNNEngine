#include "Column.h"
#include "TR1Random.h"
#include "Global.h"

Column::Column(bool createLayers, unsigned long parentId):
	NNComponent(ComponentTypeColumn)
{
	if(createLayers)
	{
		size_t layerCount = 6;												// 6 layers
		for(size_t i=0;i<layerCount;i++) 
		{
			Layer *layer1 = Layer::create(parentId);
			layers.push_back(layer1->id);
		}
	}
}

Column::~Column(void)
{
}

/*
	std::vector<long> layers;

	Location3D location;
	Size3D area;
*/

void Column::toJSON(std::ofstream& outstream)
{
	std::stringstream ss;
	LOGSTREAM(ss) << "Exporting column..." << std::endl;
	globalObject->log(ss);

	std::string sep("");
	outstream << "            { \"_type\": \"Column\", \"id\": " << id << ", \"location\": [" << location.x << ", " << location.y << ", " << location.z << "], \"size\": [" << area.h << ", " << area.w << ", " << area.d << "], \"layers\": [ " << std::endl;
	for (unsigned int i = 0; i < layers.size(); i++)
	{
		outstream << sep;
		sep = ",";
		Layer* l = globalObject->layerDB.getComponent(layers[i]);
		l->toJSON(outstream);
	}
	outstream << "           ] } " << std::endl;

}



void Column::save(void)
{
	globalObject->columnDB.save(this);
}

void Column::commit(void)
{
	globalObject->columnDB.addToCache(this);
}

Column *Column::create(SpatialDetails details, unsigned long parentId)
{
	Column *c = new Column(true,parentId);
	c->id = globalObject->nextComponent(ComponentTypeColumn);

	c->location = details.location;
	c->area = details.area;


	globalObject->insert(c);
	// connect all layers
	Layer *layer1 = globalObject->layerDB.getComponent(c->layers[0]); 
	Layer *layer2 = globalObject->layerDB.getComponent(c->layers[1]);
	Layer *layer3 = globalObject->layerDB.getComponent(c->layers[2]);
	Layer *layer4 = globalObject->layerDB.getComponent(c->layers[3]);
	Layer *layer5 = globalObject->layerDB.getComponent(c->layers[4]);
	Layer *layer6 = globalObject->layerDB.getComponent(c->layers[5]);

	layer1->projectTo(layer2); //  connect layer 1 (input) to layer 2 and 3
	layer1->projectTo(layer3);

	layer2->projectTo(layer5);
	layer3->projectTo(layer5);

	layer4->projectTo(layer2); //  connect layer 4 to layer 2,3 and 5
	layer4->projectTo(layer3);
	layer4->projectTo(layer5);

	layer5->projectTo(layer5); //  connect layer 4 to layer 2 and 3
	layer5->projectTo(layer6);

	// layer 6 is output layer


	return c;
}
/*
void Column::connectTo(Column *column)
{
	// Connect source layer1 (output) to targer layer4 (input)
	Layer *layerA = globalObject->layerDB.getComponent(layers[0]);
	Layer *layerB = globalObject->layerDB.getComponent(column->layers[3]);
	layerA->connectTo(layerB);
}
*/

void Column::projectTo(Column *column, float sparsity)
{
	// Connect source layer1 (output) to target layer4 (input)
	Layer *layerA = globalObject->layerDB.getComponent(layers[0]);
	Layer *layerB = globalObject->layerDB.getComponent(column->layers[3]);
	layerA->projectTo(layerB,sparsity);
	layerB->projectTo(layerA,sparsity);

}

void Column::cycle(void)
{
	size_t layerCount = layers.size();												// 6 layers
	for(size_t i=0;i<layerCount;i++) 
	{
		Layer *layer = globalObject->layerDB.getComponent(layers[i]);
		layer->cycle();
	}
//	std::cout << "Column " << this->id << " cycled." << std::endl;
}

void Column::initializeRandom(unsigned long parentId)
{
	
//	size_t rnd = (size_t) tr1random->generate(1,10); // Random # of Layers
/*
	size_t rnd = 6;
	for(size_t i=0;i<rnd;i++) 
	{
		Layer *l = Layer::create();
		l->initializeRandom();
		layers..insert(std::pair<long,Layer *>(l->id,l));
	}
*/	
}

void Column::initializeLayers(unsigned long parentId)
{
	std::stringstream ss;

	float sparsity = 25.0f;

	Layer *layer1 = globalObject->layerDB.getComponent(layers[0]); // generally the output layer
	Layer *layer2 = globalObject->layerDB.getComponent(layers[1]); 
	Layer *layer3 = globalObject->layerDB.getComponent(layers[2]);
	Layer *layer4 = globalObject->layerDB.getComponent(layers[3]); // generally the input layer
	Layer *layer5 = globalObject->layerDB.getComponent(layers[4]); 
	Layer *layer6 = globalObject->layerDB.getComponent(layers[5]); 

	// Layer 4 is input, layer 1 is output

	// Layer 2 and 3 connects to layer 6
//	std::cout << " Connecting layer 2 to layer 6 " << std::endl;
	LOGSTREAM(ss) << "  Projecting layer 2 to layer 6 " << std::endl;
	globalObject->log(ss);
	layer2->projectTo(layer6,sparsity);
//	std::cout << " Connecting layer 3 to layer 6 " << std::endl;
	LOGSTREAM(ss) << "  Projecting layer 3 to layer 6 " << std::endl;
	globalObject->log(ss);
	layer3->projectTo(layer6,sparsity);

	// Layer 4 connects to layer 3 and 5
//	std::cout << " Connecting layer 4 to layer 3 " << std::endl;
	LOGSTREAM(ss) << "  Projecting layer 4 to layer 3 " << std::endl;
	globalObject->log(ss);
	layer4->projectTo(layer3,sparsity);
//	std::cout << " Connecting layer 4 to layer 5 " << std::endl;
	LOGSTREAM(ss) << "  Projecting layer 4 to layer 5 " << std::endl;
	globalObject->log(ss);
	layer4->projectTo(layer5,sparsity);
	// Layer 5 connects to layer 2
//	std::cout << " Connecting layer 5 to layer 2 " << std::endl;
	LOGSTREAM(ss) << "  Projecting layer 5 to layer 2 " << std::endl;
	globalObject->log(ss);
	layer5->projectTo(layer2,sparsity);
	// Layer 6 connects to layer 1
//	std::cout << " Connecting layer 6 to layer 1 " << std::endl;
	LOGSTREAM(ss) << "  Projecting layer 6 to layer 1 " << std::endl;
	globalObject->log(ss);
	layer6->projectTo(layer1,sparsity);

}

Column *Column::instantiate(long key, size_t len, void *data)
{
	Column *column = new Column(false,0);
	column->id = key;

	char *ptr = (char*)data;

	long layerCount = 0;
	memcpy(&layerCount,ptr,sizeof(layerCount)); 	ptr+=sizeof(layerCount);

	for(size_t i=0;i<layerCount;i++)
	{
		long lid = 0;
		memcpy(&lid,ptr,sizeof(lid));
		column->layers.push_back(lid);
		ptr+=sizeof(lid);
	}
//	printf("instantiate: Column %i layersize %i\n",(int)column->id,(int)column->layers.size());
	return column;
}

Tuple *Column::getImage(void)
{
/* -- persisted values
	size_t layerCount;
	std::vector<long> layers;
*/
//	printf("GetImage: Column %i layersize %i\n",(int)this->id,(int)layers.size());


	long layerCount = layers.size();
	size_t size = sizeof(layerCount) + (layerCount * sizeof(layerCount));

	char* image = globalObject->allocClearedMemory(size);
	char* ptr = (char*)image;

	memcpy(ptr,&layerCount,sizeof(layerCount)); ptr+=sizeof(layerCount);

	for(size_t i=0;i<layerCount;i++)
	{
		long k = layers[i];
		memcpy(ptr,&k,sizeof(k));
		ptr+=sizeof(k);
	}

	Tuple* tuple = new Tuple();
	tuple->objectPtr = image;
	tuple->value = size;

	return tuple;
}

