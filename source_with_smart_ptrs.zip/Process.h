#pragma once
#include "NNComponent.h"

class Process: public NNComponent
{
public:
	Process(ComponentType type=ComponentTypeUnknown);
	virtual ~Process(void);
	inline float getDistance(void) { return distance; };
	inline void setDistance(float value) { 
		if (value < 0) {
			value = 0.1f;  // Kludge to prevent negaive index
		}
		distance = value; 
		setDirty(true); 
	};
	inline float getRate(void) { return rate; };
	 void setRate(float value); 

private:
	float distance;
	float rate;
};
