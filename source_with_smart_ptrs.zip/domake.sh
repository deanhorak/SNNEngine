#!/bin/bash
make -j 24
