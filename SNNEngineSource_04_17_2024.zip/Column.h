#pragma once
#include "NNComponent.h"
#include <map>
#include "Layer.h"
#include "Location3D.h"
#include "Size3D.h"
#include "SpatialDetails.h"

class Column: public NNComponent
{
	Column(bool createLayers, unsigned long parentId);
    friend class boost::serialization::access;
    // When the class Archive corresponds to an output archive, the
    // & operator is defined similar to <<.  Likewise, when the class Archive
    // is a type of input archive the & operator is defined similar to >>.
    template<class Archive>
    void serialize(Archive & ar, const size_t version)
	{
		ar & boost::serialization::base_object<NNComponent>(*this);
		for(unsigned int i=0;i<layers.size();i++)
		{
			ar & layers[i];
		}
/*
		std::map<long,Layer *>::iterator itLayer = layers.begin();
		for (itLayer=layers.begin(); itLayer!=layers.end(); ++itLayer)
		{
			ar & itLayer->second;
		}
*/
	}
public:
	virtual ~Column(void);
	static Column *create(SpatialDetails details, unsigned long parentId);
	void initializeRandom(unsigned long parentId);
	void initializeLayers(unsigned long parentId);
	static Column *instantiate(long key, size_t len, void *data);
	Tuple *getImage(void);

//	void connectTo(Column *column);
	void projectTo(Column *column, float sparsity=100.0f);
	void cycle(void);

	void toJSON(std::ofstream& outstream);


	std::vector<long> layers;

	Location3D location;
	Size3D area;

private:
	void save(void);
	void commit(void);


};
