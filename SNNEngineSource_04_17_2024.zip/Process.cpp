#include "Process.h"
#include "Global.h"

Process::Process(ComponentType type): 
	NNComponent(type)
{
}

Process::~Process(void)
{
}
