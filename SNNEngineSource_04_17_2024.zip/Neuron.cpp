#include "Neuron.h"
#include "TR1Random.h"
#include "Global.h"
#include "Axon.h"
#include "Dendrite.h"
#include "Synapse.h"
#include "SpatialDetails.h"

Neuron::Neuron(unsigned long parentId, int nucleusType):
	NNComponent(ComponentTypeNeuron)
{
	this->nucleusType = nucleusType;
	this->parentId = parentId;
	threshold = 0.0;
	potential = RESTING_POTENTIAL;
	firing = false;
	latch = false;
	lastfired = 0; // globalObject->current_timestep;
	// Neurons always have (at least one axon)
	if (parentId == 0) {
		std::cout << "Neuron " << id << " has an invalid parent cluster [" << parentId << "] " << std::endl;
	}
}

Neuron::~Neuron(void)
{
}

/*
	std::vector<long> axons;
	std::vector<long> dendrites;
	float threshold;
	float potential;
	NeuronType neuronType;
	Location3D location;
	int nucleusType; // What type of nucleus does this neuron belong to (eg 0 = interneuron, 1=sensory, etc) a sensory nuclear (T/F)?
*/
void Neuron::toJSON(std::ofstream& outstream)
{
	std::string sep("");
	outstream << "                        { \"_type\": \"Neuron\", \"id\": " << id << ", \"neuronType\": " << neuronType << ", \"nucleusType\": " << nucleusType << ", \"threshold\": " << threshold << ", \"potential\": " << potential << ", \"location\": [" << location.x << ", " << location.y << ", " << location.z << "], \"axons\": [ " << std::endl;
	for (unsigned int i = 0; i < axons.size(); i++)
	{
		outstream << sep;
		sep = ",";
		Axon* a = globalObject->axonDB.getComponent(axons[i]);
		a->toJSON(outstream);
	}
	outstream << "                        ], \"dendrites\": [ " << std::endl;
	sep = "";
	for (unsigned int i = 0; i < dendrites.size(); i++)
	{
		outstream << sep;
		sep = ",";
		Dendrite* d = globalObject->dendriteDB.getComponent(dendrites[i]);
		d->toJSON(outstream);
	}
	outstream << "                        ] } " << std::endl;

}

void Neuron::save(void)
{
	globalObject->neuronDB.save(this);
}

void Neuron::commit(void)
{
	globalObject->neuronDB.addToCache(this);
}


Neuron *Neuron::create(SpatialDetails details, NeuronType nType, unsigned long parentId, int nucleusType)
{
	Neuron *n = new Neuron(parentId, nucleusType);
	n->id = globalObject->nextComponent(ComponentTypeNeuron);
	n->neuronType = nType;
	globalObject->insert(n);

	Axon *a = Axon::create(n);
	n->axons.push_back(a->id);
	n->commit();
	return n;
}

long Neuron::getNucleusId(void)
{
	Cluster *cluster = globalObject->clusterDB.getComponent(parentId);
	if (cluster == NULL)
	{
		std::cout << "Neuron " << id << " has an invalid parent cluster [" << parentId << "] " << std::endl;
		return 0;
	}

	return cluster->parentId;
}

void Neuron::initializeRandom(void)
{
	
//	size_t rndA = (size_t) tr1random->generate(1,10); // Random # of Axons
//	size_t rndD = (size_t) tr1random->generate(1,10); // Random # of Dendrites
//	for(size_t i=0;i<rndA;i++) 
//	{
/*
		Axon *a = Axon::create(this);
		a->initializeRandom();
		axons.push_back(a->id);
*/
//	}
/*
	for(size_t i=0;i<rndA;i++) 
	{
		Dendrite *d = new Dendrite();
//		d->initializeRandom();
		dendrites.push_back(d);
	}
*/	
}

void Neuron::connectTo(Neuron *targetNeuron)
{
	Dendrite *dendrite = Dendrite::create(targetNeuron);
//	CollectionIterator<Axon *> it(&axons);
//	Axon *thisAxon = it.value();
	Axon *thisAxon = globalObject->axonDB.getComponent(axons[0]);
	thisAxon->insertSynapse(dendrite->getSynapseId());


	float pct = (float) tr1random->generate(1,100); // Random 1 to 100% of the axon distance 
	pct = pct / 100;
	float position = thisAxon->getDistance() * pct;

	Synapse *s = globalObject->synapseDB.getComponent(dendrite->getSynapseId());
	s->setPosition(position);
	//targetNeuron->dendrites.push_back(dendrite->id);

//	std::cout << "Neuron " << id << " connected to Neuron " << n->id << " via synapse " << dendrite->synapse->id << " so axon " << thisAxon->id <<  " now has " << thisAxon->synapses.size() << " synapses." << std::endl;

}

void Neuron::projectTo(Neuron *targetNeuron)
{
	Dendrite *dendrite = Dendrite::create(targetNeuron);
//	CollectionIterator<Axon *> it(&axons);
//	Axon *thisAxon = it.value();
	Axon *thisAxon = globalObject->axonDB.getComponent(axons[0]);
	thisAxon->insertSynapse(dendrite->getSynapseId());


	float pct = (float) tr1random->generate(1,100); // Random 1 to 100% of the axon distance 
	pct = pct / 100;
	float position = thisAxon->getDistance() * pct;

	Synapse *s = globalObject->synapseDB.getComponent(dendrite->getSynapseId());
	s->setPosition(position);
//	targetNeuron->dendrites.push_back(dendrite->id);

//	std::cout << "Neuron " << id << " connected to Neuron " << n->id << " via synapse " << dendrite->synapse->id << " so axon " << thisAxon->id <<  " now has " << thisAxon->synapses.size() << " synapses." << std::endl;

}

bool Neuron::isFromSensoryNucleus()
{
	if (this->nucleusType == SENSORY_NUCLEUS)
		return true;
	return false;
}

void Neuron::setFiring(bool value)
	{ 
	std::stringstream ss;
/*
	if (!isFromSensoryNucleus()) {
		if (value)
		{
			LOGSTREAM(ss) << "Neuron " << id << " set firing at timestamp " << globalObject->current_timestep << "." << std::endl;
		}
		else {
			LOGSTREAM(ss) << "Neuron " << id << " set non-firing at timestamp " << globalObject->current_timestep << "." << std::endl;
		}
		globalObject->log(ss);
	}
*/
	if(firing!=value) 
	{

		if (globalObject->setLogFiring)
		{
			globalObject->logFiring(this, value);
		}


		if (!isFromSensoryNucleus()) {
			if (value)
			{
				unsigned long nucId = getNucleusId();
				if (nucId != 0) {
					Nucleus* nuc = globalObject->nucleusDB.getComponent(nucId);
//					LOGSTREAM(ss) << "Neuron " << id << " in nucleus " << nuc->name  << " set firing at timestamp " << globalObject->current_timestep << "." << std::endl;
				} else 
				{
//					LOGSTREAM(ss) << "Neuron " << id << " (unknown nucleus) set firing at timestamp " << globalObject->current_timestep << "." << std::endl;
				}
			}
			else {
				unsigned long nucId = getNucleusId();
				if (nucId != 0) {
					Nucleus* nuc = globalObject->nucleusDB.getComponent(nucId);
					LOGSTREAM(ss) << "Neuron " << id << " in nucleus " << nuc->name << " set non-firing at timestamp " << globalObject->current_timestep << "." << std::endl;
				}
				else
				{
					LOGSTREAM(ss) << "Neuron " << id << " (unknown nucleus) set non-firing at timestamp " << globalObject->current_timestep << "." << std::endl;
				}
			}
//			globalObject->log(ss);
	}

		firing = value;
		setDirty(true);
		if (value) // we are firing, also set the latch
		{
			latch = value;
		}
	}
}

void Neuron::fire(void)
{
	std::stringstream ss;
	if(firing) 
	{
//		LOGSTREAM(ss) << "Neuron " << id << " already firing. Ignoring." << std::endl;
//		globalObject->log(ss);
		return;
	}
	else if(globalObject->current_timestep - lastfired < REFACTORY_PERIOD)
	{
//		LOGSTREAM(ss) << "Neuron " << id << " fired witin refactory period. Ignoring." << std::endl;
//		globalObject->log(ss);
		return;
	}

//	LOGSTREAM(ss) << "Neuron " << id << " firing." << std::endl;
//	globalObject->log(ss);

	size_t aSize = axons.size();
	for(size_t i=0;i<aSize;i++)
	{
		Axon *a = globalObject->axonDB.getComponent(axons[i]);
		a->fire();
	}

	setFiring(true);
	lastfired = globalObject->current_timestep;
	potential = RESTING_POTENTIAL;
	globalObject->insertFiring(this);

	
}

void Neuron::cycle(void)
{
/*
	CollectionIterator<Axon *> it(&axons);
	for (it.begin(); it.more(); it.next())
	{
		it.value()->cycle();
	}

	potential = 0;
	CollectionIterator<Dendrite *> it2(&dendrites);
	for (it2.begin(); it2.more(); it2.next())
	{
		Dendrite *dendrite = it2.value();
		potential  += dendrite->synapse->weight;
		dendrite->cycle();
	}
*/
	// determine whether or not we need to fire an AP
	// collect all dendrites that have delivered an AP payload
	// Is the sum payload in this interval enough to depolarize this cell?
	// If so, attach an AP to each axon (typically only one).
	if(potential > threshold && (globalObject->current_timestep - lastfired > REFACTORY_PERIOD)) 
	{
		if(firing) 
		{
			std::stringstream ss;
			LOGSTREAM(ss) << "Neuron (1) " << id << " still firing at end of refactory period. Reseting potential." << std::endl;
			globalObject->log(ss);
			setFiring(false);
			potential = RESTING_POTENTIAL;
		}
		else
		{
//			std::cout << "Neuron " << this->id << " membrane potential " << potential << " exceeded threshold " << threshold << " and is not within refactory period (" << (globalObject->current_timestep - lastfired) << ",RP=" << REFACTORY_PERIOD << ")  so is firing" << std::endl;
			potential += LEARNING_RATE;
			if(potential >= threshold)		// If we've exceeded threshold, fire
				fire();
		}
	}
	else
	{
		if(firing && globalObject->current_timestep - lastfired > REFACTORY_PERIOD)
		{
			std::stringstream ss;
			LOGSTREAM(ss) << "Neuron (2)" << id << " still firing at end of refactory period. Reseting potential." << std::endl;
			globalObject->log(ss);
			setFiring(false);
			potential = RESTING_POTENTIAL;
		}
	}
//	std::cout << "Neuron " << this->id << " cycled." << std::endl;
}

bool Neuron::isConnectedTo(Neuron *neuron)
{
	size_t aSize = neuron->axons.size();
	for(size_t j=0;j<aSize;j++)
	{
		Axon *a = globalObject->axonDB.getComponent(neuron->axons[j]);
		std::vector<long> *synapseVector = a->getSynapses();
		size_t ssize = synapseVector->size();
		for(size_t i=0;i<ssize;i++)
		{
			unsigned long sId = (*synapseVector)[i];

			Synapse *s = globalObject->synapseDB.getComponent(sId);
			Dendrite *d = globalObject->dendriteDB.getComponent(s->getOwningProcessComponentId());
			if(d->isSameNeuron(neuron->id))
			{
				return true;
			}
		}
	}	
	return false;
}

std::vector<long> *Neuron::getAxonConnectedSynapses(void)
{
//	std::cout << "Neuron " << this->id  << " getting connected synapses." << std::endl;

	std::vector<long> *connectedSynapses = new std::vector<long>();

	size_t aSize = axons.size();
	for(size_t j=0;j<aSize;j++)
	{
		Axon *a = globalObject->axonDB.getComponent(axons[j]);
//		std::cout << "Neuron " << this->id  << " getting axon " << a->id << " which has " << a->synapses.size() << " synapses." << std::endl;

		std::vector<long> *it2 = a->getSynapses();
		size_t ssize = it2->size();
		for(size_t i=0;i<ssize;i++)
		{
			connectedSynapses->push_back((*it2)[i]);
		}
	}	
	return connectedSynapses;
}

void Neuron::applySTDP(ActionPotential *ap, std::pair<std::vector<Tuple*>*, std::vector<Tuple*>* >*slices)
{
	// Get list of connected neurons by tracing all synapses on the axon to dendrites to neurons
	std::vector<long> *connectedSynapses = getAxonConnectedSynapses();
	size_t sCount = connectedSynapses->size();
	for(size_t i=0;i<sCount;i++)
	{

		float base = 1.0f;
		float currentRate = 1.0f;
		float currentWeight = 0.1f;
		float stepDown = -0.01f;
		float stepUp = 0.01f;

		long sId = (*connectedSynapses)[i];
		Synapse *targetSynapse = globalObject->synapseDB.getComponent(sId);

		long tId = targetSynapse->getOwningProcessComponentId();
		Dendrite *postSynapticDendrite = globalObject->dendriteDB.getComponent(tId);

		long pdnId = postSynapticDendrite->getNeuronId();

		Neuron *postSynapticNeuron = globalObject->neuronDB.getComponent(pdnId);

		//printf("ApplySTDP: Neuron=%ld, PostSynaptic (Neuron=%ld, dendrite=%ld) \n",this->id,pdnId,tId);

		if(this->firing)
		{
			//printf("...IsFiring\n");
			if(postSynapticNeuron->isFiring(REFACTORY_PERIOD)) 
			{

				// source and target both firing - increase weight up to limit
//				float currentWeight = targetSynapse->getWeight();
//				if(currentWeight < base)
//				{
//					targetSynapse->setWeight(currentWeight + stepDown);
////					std::cout << "Neuron " << this->id  << " and  target neuron " << targetNeuron->id << " both firing. Increase weight." << std::endl;
//				}
//				else
//				{
//					targetSynapse->setWeight(base);
////					std::cout << "Neuron " << this->id  << " and  target neuron " << targetNeuron->id << " both firing. Already at max weight." << std::endl;
//				}
			}
			else
			{
				// Call the stdp calculation produced by OpenAI.ChatGPT
				// However, we need an array of timedEvents timestamps of all events up to 10ms before and 10ms after this timeslice
				// First thought is to move all expired APs into a backup set of vectors before destroying them. 
				// Then spin through all backup vectors accumulating the timestamps into a vector which is returned as an array of timestamps as pre-spike times
				// Then spin through all main timedevent vectors accumulating the timestamps into a vector which is returned as an array of timestamps as post-spike times
				// 
//				float w1 = targetSynapse->getWeight();
				stdp_update(targetSynapse, slices);
/*				
				float w2 = targetSynapse->getWeight();

				Dendrite *d = targetSynapse->getOwningProcessComponent(); // globalObject->dendriteDB.getComponent(dendrite_id);
				long nId = d->getNeuronId();
				Neuron *tgtNeuron = globalObject->neuronDB.getComponent(nId);

				long sId = this->id;

				Nucleus *nuc1 = globalObject->nucleusDB.getComponent(this->getNucleusId());
				Nucleus *nuc2 = globalObject->nucleusDB.getComponent(tgtNeuron->getNucleusId());

				if(nuc1->id != nuc2->id) 
				{
					std::stringstream msg;
					msg << "stdp_update synapse:" << targetSynapse->id << " src:" << sId << "[" << nuc1->name << "]" << ", tgt:" << nId << "[" << nuc2->name << "]" << ", wgt:" << w1 << " > " << w2 ;
					globalObject->debug(msg);
				}
*/

				// source firing but target not firing 
//				unsigned long elapsed = globalObject->current_timestep - postSynapticNeuron->lastfired;
//				if(elapsed < 10) // if target was recently (10ms) fired increase mylenation 
//				{
//					float currentRate = postSynapticDendrite->getRate();
//					if(currentRate< base)
//					{
//						postSynapticDendrite->setRate(currentRate+ stepUp);
////						std::cout << "Neuron " << this->id  << " firing, but target neuron " << targetNeuron->id << " not firing, so dendrite " << targetSynapse->owningprocess->id << " mylenation increased." << std::endl;
//					}
//					else
//					{
//						postSynapticDendrite->setRate(base);
////						std::cout << "Neuron " << this->id  << " firing, but target neuron " << targetNeuron->id << " not firing, but dendrite " << targetSynapse->owningprocess->id << " mylenation already at max so no change." << std::endl;
//					}
//				}
//				else
//				{
////					std::cout << "Neuron " << this->id  << " firing, but target neuron " << targetNeuron->id << " not firing, but target not recently fired, so no change in synapse " << targetSynapse->id << "." << std::endl;
//				}
			}
		}
		else
		{
			if(postSynapticNeuron->isFiring(REFACTORY_PERIOD))
			{

				unsigned long elapsed = globalObject->current_timestep - this->lastfired;
				if(elapsed < 10) // if target was recently (10ms) fired strengthen it
				{
					currentRate = postSynapticDendrite->getRate();
					if(currentRate > base)
					{
						postSynapticDendrite->setRate(currentRate + stepDown);
//						std::cout << "Neuron " << this->id  << " not firing, but target neuron " << targetNeuron->id << " firing, so dendrite " << targetSynapse->owningprocess->id << " mylenation decreased." << std::endl;
					}
					else
					{
						postSynapticDendrite->setRate(base);
//						std::cout << "Neuron " << this->id  << " not firing, but target neuron " << targetNeuron->id << " firing, but dendrite " << targetSynapse->owningprocess->id << " mylenation already at min so no change." << std::endl;
					}

					targetSynapse->setWeight(targetSynapse->getWeight() + stepUp);
//					std::cout << "Neuron " << this->id  << " firing, but target neuron " << targetNeuron->id << " not firing, so synapse " << targetSynapse->id << " weight increased." << std::endl;
				}
				else
				{
					currentWeight = targetSynapse->getWeight();
					if(currentRate > base)
					{
						targetSynapse->setWeight(currentWeight + stepDown);
//						std::cout << "Neuron " << this->id << " not recently fired, but target neuron " << targetNeuron->id << " firing, so synapse " << targetSynapse->id << " weight decreased." << std::endl;
					}
					else
					{
						targetSynapse->setWeight(base);
//						std::cout << "Neuron " << this->id << " not recently fired, but target neuron " << targetNeuron->id << " firing, but synapse " << targetSynapse->id << " weight already at min so no change." << std::endl;
					}
				}
// DSH 11/17/2022
				potential += targetSynapse->getWeight(); // Adjust the neuron's potential based on the synapse weight 
			}
			else
			{
				// source not firing and target not firing - leave alone
//				std::cout << "Neuron " << this->id << " not firing, and target neuron " << targetNeuron->id << " not firing, so don't adust weight of synapse " << targetSynapse->id << "." << std::endl;
			}
		}

	}

	delete connectedSynapses;

//	std::cout << "Neuron " << this->id  << " adjusted. (synapse count=" << sCount << ")." << std::endl;

}
//

Tuple *Neuron::getImage(void)
{
/* -- persisted values
	NeuronType neuronType;
	float threshold;
	float potential;
	std::map<long,Axon *> axons;
	std::map<long,Dendrite *> dendrites;
*/
	long axonCount = (u_int32_t)axons.size();
	long dendriteCount = (u_int32_t)dendrites.size();


	size_t size = sizeof(nucleusType)+ sizeof(parentId) + sizeof(neuronType) + sizeof(threshold) + sizeof(potential) +
		sizeof(location.x) + sizeof(location.y) + sizeof(location.z) + sizeof(axonCount) + (axonCount * sizeof(long)) + sizeof(dendriteCount) + (dendriteCount * sizeof(long));

	char* image = globalObject->allocClearedMemory (size);
	char *ptr = (char*)image;
	unsigned long processId = 0;

//	memcpy(ptr,&size,sizeof(u_int32_t)); 	ptr+=sizeof(u_int32_t);

	memcpy(ptr, &nucleusType,	sizeof(nucleusType)); 	ptr += sizeof(nucleusType);
	memcpy(ptr, &parentId,		sizeof(parentId));		ptr += sizeof(parentId);
	memcpy(ptr, &neuronType,	sizeof(neuronType)); 	ptr += sizeof(neuronType);
	memcpy(ptr,&threshold,		sizeof(threshold));		ptr+=sizeof(threshold);
	memcpy(ptr,&potential,		sizeof(potential));		ptr+=sizeof(potential);
	memcpy(ptr, &location.x,	sizeof(location.x));	ptr += sizeof(location.x);
	memcpy(ptr, &location.y,	sizeof(location.y));	ptr += sizeof(location.y);
	memcpy(ptr, &location.z,	sizeof(location.z));	ptr += sizeof(location.z);
	memcpy(ptr,&axonCount,		sizeof(axonCount)); 	ptr+=sizeof(axonCount);
	memcpy(ptr,&dendriteCount,	sizeof(dendriteCount)); ptr+=sizeof(dendriteCount);

	for(size_t i=0;i< axonCount;i++)
	{
		processId = axons[i];
		memcpy(ptr,&processId,sizeof(processId));
		ptr+=sizeof(processId);
	}
	for(size_t i=0;i< dendriteCount;i++)
	{
		processId = dendrites[i];
		memcpy(ptr,&processId,sizeof(processId));
		ptr+=sizeof(processId);
	}

	Tuple* tuple = new Tuple();
	tuple->objectPtr = image;
	tuple->value = size;

	return tuple;
}

Neuron *Neuron::instantiate(long key, size_t len, void *data)
{
// 	u_int32_t size = sizeof(float)+sizeof(float)+sizeof(u_int32_t)+(axons.size()*sizeof(long))+sizeof(u_int32_t)+(dendrites.size()*sizeof(long));

	unsigned long defaultClusterId = ComponentType::ComponentTypeCluster;

	long axonCount = 0;
	long dendriteCount = 0;

	size_t size = sizeof(nucleusType) + sizeof(parentId) + sizeof(neuronType) + sizeof(threshold) + sizeof(potential) +
		sizeof(location.x) + sizeof(location.y) + sizeof(location.z) + sizeof(axonCount) + sizeof(dendriteCount);


	Neuron *neuron = new Neuron(defaultClusterId,INTER_NUCLEUS);
	neuron->id = key;
	char *ptr = (char*)data;

	memcpy(&neuron->nucleusType,ptr,	sizeof(nucleusType)); 	ptr += sizeof(nucleusType);
	memcpy(&neuron->parentId,	ptr,	sizeof(parentId));		ptr += sizeof(parentId);
	memcpy(&neuron->neuronType,	ptr,	sizeof(neuronType));	ptr+=sizeof(neuronType);
	memcpy(&neuron->threshold,	ptr,	sizeof(threshold)); 	ptr+=sizeof(threshold);
	memcpy(&neuron->potential,	ptr,	sizeof(potential));		ptr+=sizeof(potential);
	memcpy(&neuron->location.x, ptr,	sizeof(location.x));	ptr += sizeof(location.x);
	memcpy(&neuron->location.y, ptr,	sizeof(location.y));	ptr += sizeof(location.y);
	memcpy(&neuron->location.z, ptr,	sizeof(location.z));	ptr += sizeof(location.z);
	memcpy(&axonCount,			ptr,	sizeof(axonCount));		ptr+=sizeof(axonCount);
	memcpy(&dendriteCount,		ptr,	sizeof(dendriteCount));	ptr+=sizeof(dendriteCount);

	for(size_t i=0;i<axonCount;i++)
	{
		long thisKey;
		memcpy(&thisKey,ptr,sizeof(long));
		ptr+=sizeof(long);
		neuron->axons.push_back(thisKey);
	}
	for(size_t i=0;i<dendriteCount;i++)
	{
		long thisKey;
		memcpy(&thisKey,ptr,sizeof(long));
		ptr+=sizeof(long);
		neuron->dendrites.push_back(thisKey);
	}

	return neuron;
}

long Neuron::getCurrentTimestep(void) {
	return globalObject->current_timestep;
}

////////////////////////////////////////// OPENAI.CHATGPT OUTPUT //////////////////////////////
#include <stdio.h>
#include <stdlib.h>


std::string Neuron::getLocationOfNeuron(void)
{
	std::string retString;

	// iterate through nuclei
	// nucleus base=300000000
	for(long nucidx=0;nucidx<globalObject->nucleusDB.size();nucidx++) 
	{
		long nucid = globalObject->componentBase[ComponentTypeNucleus] + nucidx;
		Nucleus *nucleus = globalObject->nucleusDB.getComponent(nucid);
		int columns = nucleus->columns.size();
		for(int i=0;i<columns;i++) 
		{
			Column *column = globalObject->columnDB.getComponent(nucleus->columns[i]);
			int  layers = column->layers.size();
			for(int j=0;j<layers;j++) 
			{
				Layer *layer = globalObject->layerDB.getComponent(column->layers[j]);
				int  clusters = layer->clusters.size();
				for(int k=0;k<clusters;k++) 
				{
					Cluster *cluster = globalObject->clusterDB.getComponent(layer->clusters[k]);
					int neurons = cluster->neurons.size();
					for(int m=0;m<neurons;m++) 
					{
						if(cluster->neurons[m] == this->id) // if equal we found our neuron
						{
							std::stringstream sss;

							//sss << nucleus->name << "/Column " << column->id << "/Layer " << (j+1) << "/Cluster " << cluster->id << "/Neuron " << this->id;
							sss << nucleus->name << "/" << (j+1) << "/" << this->id;
							retString = sss.str();
							break;
						}
					}
				}
			}
		}

	}

	return retString;

}

/* Function to perform a "spike timing dependent plasticity" operation for a single synapse,
 * given detail timing information about spikes arriving up to 10 milliseconds before or after
 * the arrival of the current spike.
 */
void Neuron::stdp_update(Synapse* synapse, std::pair<std::vector<Tuple*>*, std::vector<Tuple*>* >* pair) {
	double delta;

	//std::pair<std::vector<Tuple*>*, std::vector<Tuple*>*> *pair = globalObject->getSpikes();
	std::vector<Tuple *>* preSpikes = pair->first;
	std::vector<Tuple *>* postSpikes = pair->second;
//	delete pair;

//	if(preSpikes->size() >0 || postSpikes->size() > 0)
// 		printf("Pre: %d, Post: %d\n",preSpikes->size(), postSpikes->size());

	//std::vector<Tuple*>* preSpikes = globalObject->getPreSpikes();
	size_t num_pre_spikes = preSpikes->size();
	unsigned long axonId = axons[0]; // only one axon
//	std::string location = getLocationOfNeuron();

	for (size_t i = 0; i < num_pre_spikes; i++) {
		Tuple* tuple = (*preSpikes)[i];
		TimedEvent* te = (TimedEvent*)tuple->objectPtr;
		unsigned long t = (unsigned long)tuple->value; // timestamp
		ActionPotential* ap = te->ap;
		//ap->owningProcessId; dendrite or axon?
		if (ap->owningProcessId == axonId) 
		{

			delta = DEFAULT_STDP_RATE * exp((globalObject->current_timestep - t) / -10.0);
			float oldWeight = synapse->getWeight();
			float newWeight = oldWeight - (float)delta;
/*
			std::stringstream debugmsg;
			if(newWeight > oldWeight)
				debugmsg << " A[" << location << "/" << synapse->id << "/" << ap->owningProcessId << "] " << oldWeight << " INC " << newWeight;
			else 
				debugmsg << " A[" << location << "/" << synapse->id << "/" << ap->owningProcessId << "] " << oldWeight << " DEC " << newWeight;
			globalObject->debug(debugmsg);
			*/

			synapse->setWeight(newWeight);
		}
		else // must be a dendrite adjust weight
		{
			delta = DEFAULT_STDP_RATE * exp((globalObject->current_timestep - t) / -10.0);
			float oldWeight = synapse->getWeight();
			float newWeight = oldWeight - (float)delta;
/*
			std::stringstream debugmsg;
			if(newWeight > oldWeight)
				debugmsg << " D[" << location << "/" << synapse->id << "/" << ap->owningProcessId << "] " << oldWeight << " INC " << newWeight;
			else 
				debugmsg << " D[" << location << "/" << synapse->id << "/" << ap->owningProcessId << "] " << oldWeight << " DEC " << newWeight;
			globalObject->debug(debugmsg);
*/
			synapse->setWeight(newWeight);
		}

		//delete tuple;
//		debugmsg.str("");
//		debugmsg << "stdp-update complete:";
//		globalObject->debug(debugmsg);

	}

	//std::vector<Tuple*>* postSpikes = globalObject->getPostSpikes();
	size_t num_post_spikes = postSpikes->size();

	for (size_t i = 0; i < num_post_spikes; i++) {
		Tuple* tuple = (*postSpikes)[i];
		TimedEvent* te = (TimedEvent*)tuple->objectPtr;
		unsigned long t = (unsigned long)tuple->value; // timestamp
		ActionPotential* ap = te->ap;
		ap->owningProcessId; // dendrite or axon?
		if (ap->owningProcessId == axonId) 
		{
			delta = DEFAULT_STDP_RATE * exp((t - globalObject->current_timestep) / 10.0);
			float newWeight = synapse->getWeight() + (float)delta;
			synapse->setWeight(newWeight);
		} 
		else // must be a dendrite adjust weight
		{ 
			delta = DEFAULT_STDP_RATE * exp((t - globalObject->current_timestep) / 10.0);
			float newWeight = synapse->getWeight() + (float)delta;
			synapse->setWeight(newWeight);
		}
		//delete tuple;
	}
//	delete preSpikes;
//	delete postSpikes;
}
