#pragma once
#include <stdio.h>
#include "stdafx.h"
#include "Process.h"
#include "NNComponent.h"

class Global;
extern Global *globalObject;

class ActionPotential: public NNComponent
{
	ActionPotential(Process *p);
/*
    friend class boost::serialization::access;
    // When the class Archive corresponds to an output archive, the
    // & operator is defined similar to <<.  Likewise, when the class Archive
    // is a type of input archive the & operator is defined similar to >>.
    template<class Archive>
    void serialize(Archive & ar, const size_t version)
	{
		ar & boost::serialization::base_object<NNComponent>(*this);
        ar & initialTimestamp;
        ar & owningProcess->id;
        ar & position;
        ar & lastposition;
        ar & rate;
        ar & finished;
	}
*/
public:
	~ActionPotential(void);
	static ActionPotential *create(Process *p);
//	void cycle(void);
	void insertEvents(void);
//	ActionPotential *clone(void);

//	long initialTimestamp;
	unsigned long owningProcessId;
//	float position;
//	float lastposition;
//	float rate;
//	bool finished;
};
