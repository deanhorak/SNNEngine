#include "TimedEvent.h"
#include "Global.h"

TimedEvent::TimedEvent(long timeSlice):
	NNComponent(ComponentTypeTimedEvent)
{
	slice = timeSlice;
	ap = NULL;
	id = globalObject->nextComponent(ComponentTypeTimedEvent);
}

TimedEvent::~TimedEvent(void)
{
}

TimedEvent *TimedEvent::create(long timeSlice, ActionPotential* ap, long synapseId)
{
	TimedEvent *te = new TimedEvent(timeSlice);
	te->ap = ap;
	te->synapseId = synapseId;
	return te;
}
