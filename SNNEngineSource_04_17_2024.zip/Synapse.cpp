#include "Synapse.h"
#include "Global.h"
#include "TR1Random.h"

Synapse::Synapse(Dendrite *dendrite):
	NNComponent(ComponentTypeSynapse)
{
	size_t rnd = (size_t) tr1random->generate(1,1000); // Random # between one and 1000
	if(rnd<=100) // if random number == 5 (.1%) the set weight to 1 
	{
//		std::cout << "Synapse " << id << " randomly primed with a weight of 1"  << std::endl;
		weight = 1.0;
	}
	else
	{
		weight = 0.25;
	}

	position = (float)tr1random->generate(1,1000); // Random # between one and 1000;
	setOwningProcessComponentId(dendrite->id);
	dendrite->setDirty();
}

Synapse::Synapse(void):
	NNComponent(ComponentTypeSynapse)
{
	weight = 0.0;
	position = 0;
	setOwningProcessComponentId(0);
}

Synapse::~Synapse(void)
{
}

/*
	unsigned long owningprocessId;
	float weight;
	float position;
*/
void Synapse::toJSON(std::ofstream& outstream)
{
	outstream << "                                { \"_type\": \"Synapse\", \"id\": " << id << ", \"owningprocessId\": " << owningprocessId << ", \"weight\": " << weight << ", \"position\": " << position <<  " } " << std::endl;
}


void Synapse::save(void)
{
	globalObject->synapseDB.save(this);
}

void Synapse::commit(void)
{
	globalObject->synapseDB.addToCache(this);
}


Synapse *Synapse::create(Dendrite *dendrite)
{
	Synapse *s = new Synapse(dendrite);
	s->id = globalObject->nextComponent(ComponentTypeSynapse);
	s->position = dendrite->getDistance();
	globalObject->insert(s);
	return s;
}

void Synapse::receiveAP(ActionPotential *ap)
{
	Dendrite *dendrite = getOwningProcessComponent();
	bool pass = false;
	/////////////////////////////////////////////////////////////////////
	// DSH 
	// KEY COMPONENT OF THE LOGIC In need of further development
	// HOw to make the decision on whether or not to pass the spike onto the dendrite
	// For now, we compare the syapse's weight to a simple threshold value (50%)
	//	IF it's weight is greater than or equal to a fixed value (0.5), 
	//		THEN pass the AP on by firing the dendrite
	//		ELSE ignore the AP
	// 
	//////////////////////////////////////////////////////////////////// 
	if(this->weight >= 0.5f) // threshold?
		pass = true;



	if(pass) 
	{
	//	std::cout << "Synapse " << id << " (on Dendrite " << dendrite->id << ") triggered by AP " << ap->id << " and current weight is " << weight << " so firing "  << std::endl;
		dendrite->fire();
	}
	else 
	{
	//	std::cout << "Synapse " << id << " (on Dendrite " << dendrite->id << ") received AP " << ap->id << " and current weight is " << weight << " so not forwarded"  << std::endl;
	}
}

Tuple *Synapse::getImage(void)
{
/* -- persisted values
	Dendrite *owningprocess;
	float weight;
	float position;
*/

	size_t size = sizeof(owningprocessId)+sizeof(weight)+sizeof(position);

	char *image = globalObject->allocClearedMemory(size);
	char *ptr = (char*)image;

	memcpy(ptr,&owningprocessId,sizeof(owningprocessId)); 	ptr+=sizeof(owningprocessId);
	memcpy(ptr,&weight,sizeof(weight)); 	ptr+=sizeof(weight);
	memcpy(ptr,&position,sizeof(position)); 	ptr+=sizeof(position);

	Tuple* tuple = new Tuple();
	tuple->objectPtr = image;
	tuple->value = size;

	return tuple;
}

Synapse *Synapse::instantiate(long key, size_t len, void *data)
{
// 	u_int32_t size = sizeof(long)+sizeof(float)+sizeof(float);

	Synapse *synapse = new Synapse();
	synapse->id = key;
	char *ptr = (char*)data;

	memcpy(&synapse->owningprocessId,ptr,sizeof(synapse->owningprocessId)); 	ptr+=sizeof(synapse->owningprocessId);
	memcpy(&synapse->weight,ptr,sizeof(synapse->weight)); 	ptr+=sizeof(synapse->weight);
	memcpy(&synapse->position,ptr,sizeof(synapse->position)); 	ptr+=sizeof(synapse->position);

	return synapse;
}

Dendrite *Synapse::getOwningProcessComponent(void) 
{ 
	return globalObject->dendriteDB.getComponent(owningprocessId); 
};

