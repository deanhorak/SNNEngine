#pragma once
#include <map>
#include <vector>
#include "Process.h"
#include "Synapse.h"
#include "ActionPotential.h"

//class Neuron { long id; };
class Axon: public Process
{
    friend class boost::serialization::access;
    // When the class Archive corresponds to an output archive, the
    // & operator is defined similar to <<.  Likewise, when the class Archive
    // is a type of input archive the & operator is defined similar to >>.
    template<class Archive>
    void serialize(Archive & ar, const size_t version)
	{
		ar & boost::serialization::base_object<NNComponent>(*this);
        ar & neuronId;

        for(unsigned int i=0;i<synapses.size();i++)
        {
        	ar & synapses[i];
        }
/*
		std::map<long,Synapse *>::iterator itSynapse = synapses.begin();
		for (itSynapse=synapses.begin(); itSynapse!=synapses.end(); ++itSynapse)
		{
			ar & itSynapse->second;
		}
*/
//		std::map<long,ActionPotential *>::iterator itActionPotential = actionpotentials.begin();
//		for (itActionPotential=actionpotentials.begin(); itActionPotential!=actionpotentials.end(); ++itActionPotential)
//		{
//			ar & itActionPotential->second;
//		}
	}

public:
	virtual ~Axon(void);
	static Axon *create(Neuron *neuron);
	void initializeRandom(void);
//	void cycle(void);
	void fire(void);
	void removeDeadAPs(void);
	Tuple *getImage(void);
	static Axon *instantiate(long key, size_t len, void *data);
	inline std::vector<long> *getSynapses(void) { return &synapses; };
	void insertSynapse(long synapseId); 
	void toJSON(std::ofstream& outstream);

	long neuronId;

private:

	Axon(void);
	Axon(Neuron* neuron);

	void save(void);
	void commit(void);

	std::vector<long> synapses;
//	std::map<long,ActionPotential *> actionpotentials;

};

