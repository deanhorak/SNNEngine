#include "Global.h"
#include "ActionPotential.h"
#include "Axon.h"
#include "Dendrite.h"


ActionPotential::ActionPotential(Process *p): 
	NNComponent(ComponentTypeActionPotential)
{
	owningProcessId = p->id;
	this->id = globalObject->nextComponent(ComponentTypeActionPotential);
//	finished = false;
//	position = 0;
//	lastposition = 0;
//	initialTimestamp = globalObject->current_timestep;
	insertEvents();
}

ActionPotential::~ActionPotential(void)
{
}

ActionPotential *ActionPotential::create(Process *p)
{
	ActionPotential *a = new ActionPotential(p);
//	a->id = globalObject->nextComponent(ComponentTypeActionPotential);
	globalObject->addAP(a);
	return a;
}

// Compute the offset into the future (in ms) from current position along axon and speed (rate). 
int computeOffset(float position, float rate) 
{
	int offset = (int)(position * rate);
//	if(position==0) {
//		printf("computeOffset(): position=%f rate=%f offset=%d \n",position,rate,offset);
//	}
//	printf("computeOffset(): position->%f rate->%f %d \n",position,rate,offset);
	return offset;
}

void ActionPotential::insertEvents(void)
{
	if(owningProcessId >= globalObject->componentBase[ComponentTypeAxon] && owningProcessId < globalObject->componentBase[ComponentTypeDendrite])
	{
		//
		// Process as Axon
		//
		Axon *axon = globalObject->axonDB.getComponent(owningProcessId);
//		Axon *axon = (Axon *)owningProcess;
		std::vector<long> *it = axon->getSynapses();
		size_t sz = it->size();
		for (size_t i=0;i<sz;i++)
		{
			long k = (*it)[i];
			Synapse *s = globalObject->synapseDB.getComponent(k);
			int offset = computeOffset(s->getPosition(), axon->getRate());
			if(offset < MAX_TIMEINTERVAL_BUFFER_SIZE) 
			{
				if(offset!=0)  // don't create an event with offset zero since it won't be utilized anyway
				{
					//int offset = (int) (s->getPosition() * axon->getRate()); 
				
					TimedEvent *te = TimedEvent::create(globalObject->current_timestep + offset, this, s->id);

					globalObject->insert(te,offset);

				//printf("Offset1 %d\n",offset);
				}
			} else {
				std::cout << "Offset too large " << offset << ". Greater than " << MAX_TIMEINTERVAL_BUFFER_SIZE << std::endl;
			}
		}
	}
	else
	{
		//
		// Process as Dendrite
		//
		Dendrite *dendrite = globalObject->dendriteDB.getComponent(owningProcessId);
//		Dendrite *dendrite = (Dendrite *)owningProcess;
		int offset = (int) (dendrite->getDistance() * dendrite->getRate());
		if(offset!=0)  // don't create an event with offset zero since it won't be utilized anyway
		{ 
			if(offset> MAX_TIMEINTERVAL_BUFFER_SIZE)
			{
				std::cout << "Dendrite Offset too large " << offset << ". Greater than " << MAX_TIMEINTERVAL_BUFFER_SIZE << std::endl;
			} 
			else 
			{
			TimedEvent *te = TimedEvent::create(globalObject->current_timestep + offset, this, 0L);

			globalObject->insert(te,offset);
			// printf("Offset2 %d\n",offset);
			}
		}
	}
}