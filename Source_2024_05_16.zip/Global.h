#pragma once

//
//#define BRAINDEMO BrainDemoSimple
//#define BRAINDEMONAME "BrainDemoSimple"
//#define BRAINDEMO BrainDemo
//#define BRAINDEMONAME "BrainDemo"
//#define DB_PATH "../database/"
//#define BRAINDEMO BrainDemo6
//#define BRAINDEMONAME "BrainDemo6"

#define BRAINDEMO BrainDemoHWRecognition
#define BRAINDEMONAME "BrainDemoHWRecognition"

//#define BRAINDEMO DetailTest
//#define BRAINDEMONAME "DetailTest"

#include <stdio.h>
#include <map>
#include <vector>
#include <string>
#include <iostream>
#include <sstream>
#include <boost/thread.hpp>
#include <boost/asio.hpp>
#include <boost/asio/post.hpp>
#include <boost/asio/thread_pool.hpp>
//#include <boost/json.hpp>

//#include <vld.h>

#include "NNComponent.h"
#include "Brain.h"
#include "Region.h"
#include "Nucleus.h"
#include "Column.h"
#include "Layer.h"
#include "Cluster.h"
#include "Neuron.h"
#include "Axon.h"
#include "Dendrite.h"
#include "Synapse.h"
#include "ActionPotential.h"
#include "TimedEvent.h"
#include "CollectionIterator.h"
#include "ComponentDB.h"
#include "Location3D.h"

#define MAX_TIMEINTERVAL_BUFFER_SIZE 10000
#define MAX_THREADPOOL_SIZE 20
#define THREADPOOL_SLICE_THRESHOLD 1000 // super large value 
#define MAX_ACTIVE_ACTIONPOTENTIALS 5000000 // 5 million

#define DEFAULT_AXON_RATE 0.05
#define DEFAULT_AXON_RATE_STEP 0.01
#define DEFAULT_DENDRITE_RATE 0.05
#define DEFAULT_DENDRITE_RATE_STEP 0.01
#define DEFAULT_STDP_RATE 0.01


#define LOGSTREAM(s) s.str(""); s.clear(); s 

// #define u_int32_t uint32_t

class Global
{
private:
//	std::map<long,Brain *> brains;
//	std::map<long,Region *> regions;
//	std::map<long,Nucleus *> nuclei;
//	std::map<long,Column *> columns;
//	std::map<long,Layer *> layers;
//	std::map<long,Cluster *> clusters;
//	std::map<long,Neuron *> neurons;
//	std::map<long,Axon *> axons;
//	std::map<long,Dendrite *> dendrites;
//	std::map<long,Synapse *> synapses;
public:

//	std::map<long,ActionPotential *> actionpotentials;
	boost::mutex xThreadQueue_mutex;
	std::queue<std::string> xThreadQueue;

	Global(void);
	virtual ~Global(void);
	void increment(void);
//	void removeAP(ActionPotential *ap);
//	void removeAPNoMux(ActionPotential* ap);
//	size_t removeTimedEvent(TimedEvent *te);
//	size_t removeExpiredEvents(void);
	void addTimedEvent(TimedEvent* te);
//	void addAP(ActionPotential *ap);
	long nextComponent(ComponentType type);
//	void removeDeadAPs(void);
//	void tagDeadAPs(void);
	void runCycle(void);
	void cycle(void);
	void cycleSlice(std::vector<TimedEvent*>* teVector, size_t start, size_t count, bool display, size_t intervalOffsetValue,std::pair<std::vector<Tuple *> *, std::vector<Tuple *> *> *spikes);
	void flush(void);
	void flushAll(void);
	void shutdown(void);
	void log(char *str);
	void log(std::stringstream &ss);
	void logFiring(Neuron *n,bool firestatus);

	long getTotalEvents(void);

	void debug(char *str);
	void debug(std::stringstream &ss);

	std::map<long,Neuron *> firingNeurons;

	std::vector<float> softmax(const std::vector<float>& input);
	std::pair<std::vector<Tuple*>*, std::vector<Tuple*>* > *getSpikes(long now, long interval);

	//static void stdp(Neuron* n, ActionPotential* ap, std::pair<std::vector<Tuple*>*, std::vector<Tuple*>* >* slices);
	void applySTDP(Neuron* n, ActionPotential* ap, std::pair<std::vector<Tuple*>*, std::vector<Tuple*>* >*slices);

	char* allocClearedMemory(size_t count);
	void freeMemory(char *ptr);

	bool componentKeyInRange(unsigned long key);
	bool validTimedEvent(unsigned long id);
	bool validActionPotential(unsigned long id);

	void loadAll(void);

	size_t getTypeIndex(std::string  name);

	// Brain
//	static std::map<long,Brain *> *getBrainsCollection(void);
	void insert(Brain *brain);
	size_t brainSize(void);

	// Region
//	static std::map<long,Region *> *getRegionsCollection(void);
	void insert(Region *region);
	size_t regionsSize(void);

	// Nucleus
//	static std::map<long,Nucleus *> *getNucleiCollection(void);
	void insert(Nucleus *nucleus);
	size_t nucleiSize(void);

	// Column
//	static std::map<long,Column *> *getColumnsCollection(void);
	void insert(Column *column);
	size_t columnsSize(void);

	// Layer
//	static std::map<long,Layer *> *getLayersCollection(void);
	void insert(Layer *layer);
	size_t layersSize(void);

	// Cluster
//	static std::map<long,Cluster *> *getClustersCollection(void);
	void insert(Cluster *cluster);
	size_t clustersSize(void);

	// Neuron
//	static std::map<long,Neuron *> *getNeuronsCollection(void);
	void insert(Neuron *neuron);
	size_t neuronsSize(void);

	// Axon
//	static std::map<long,Axon *> *getAxonsCollection(void);
	void insert(Axon *axon);
	size_t axonsSize(void);

	// Dendrite
//	static std::map<long,Dendrite *> *getDendritesCollection(void);
	void insert(Dendrite *dendrite);
	size_t dendritesSize(void);

	// Synapse
//	static std::map<long,Synapse *> *getSynapsesCollection(void);
	void insert(Synapse *synapse);
	size_t synapsesSize(void);

	// ActionPotential
//	static std::map<long,ActionPotential *> *getActionPotentialsCollection(void);
//	ActionPotential *getActionPotential(long);
//	std::vector<long>* getActionPotentialKeysCollection(void);
//	void globalInsert(ActionPotential *actionPotential);
//	size_t actionPotentialsSize(void);

	// TimedEvent
//	static std::vector<TimedEvent *> *getTimedEventCollection(void);
	void insert(TimedEvent *timedEvent,int intervalOffset);
//	size_t timedEventSize(void);

	void insertFiring(Neuron *neuron);

	void writeSyncpoint(int sp);
	int readSyncpoint(void);

	std::string getMessage(void);
	void putMessage(std::string);

	//void launchBatch(std::vector<TimedEvent*>* teVector, int tevSize, size_t intervalOffsetValue);

	void writeFireLog(std::string msg);
	void closeFireLog(void);
	void closeDebugLog(void);

	void writeEventLog(std::string msg);
	void closeEventLog(void);

	
// trim from start (in place)
	static inline std::string &ltrim(std::string& s) {
		s.erase(s.begin(), std::find_if(s.begin(), s.end(), [](unsigned char ch) {
			return !std::isspace(ch);
			}));
		return s;
	}

	// trim from end (in place)
	static inline std::string &rtrim(std::string& s) {
		s.erase(std::find_if(s.rbegin(), s.rend(), [](unsigned char ch) {
			return !std::isspace(ch);
			}).base(), s.end());
		return s;
	}

	// trim from both ends (in place)
	static inline std::string &trim(std::string& s) {
		ltrim(s);
		rtrim(s);
		return s;
	}

	// trim from start (copying)
	static inline std::string ltrim_copy(std::string s) {
		ltrim(s);
		return s;
	}

	// trim from end (copying)
	static inline std::string rtrim_copy(std::string s) {

		rtrim(s);
		return s;
	}

	// trim from both ends (copying)
	static inline std::string trim_copy(std::string s) {
		trim(s);
		return s;
	}

	/////////////////////////////


	unsigned long componentBase[CTYPE_COUNT];
	long componentCounter[CTYPE_COUNT];
	long componentCounter2[CTYPE_COUNT];
	long current_timestep;
	boost::posix_time::ptime startRealTime;

	//std::map<long, TimedEvent*> allTimedEvents;
	std::map<long, TimedEvent*> allTimedEvents;
	
	std::vector<TimedEvent *> timeIntervalEvents[MAX_TIMEINTERVAL_BUFFER_SIZE];
//	std::vector<TimedEvent *> backupTimeIntervalEvents[MAX_TIMEINTERVAL_BUFFER_SIZE];

	ComponentDB<Layer> layerDB;
	ComponentDB<Cluster> clusterDB;
	ComponentDB<Column> columnDB;
	ComponentDB<Nucleus> nucleusDB;
	ComponentDB<Region> regionDB;
	ComponentDB<Brain> brainDB;
	ComponentDB<Neuron> neuronDB;
	ComponentDB<Axon> axonDB;
	ComponentDB<Dendrite> dendriteDB;
	ComponentDB<Synapse> synapseDB;

	std::vector<NNComponent *> deletedComponents;

	boost::asio::thread_pool *workers = NULL;


	int syncpoint;

	Location3D nullLocation;

	std::ofstream *firefile = NULL;
	std::ofstream *firelogfile = NULL;
	std::ofstream *debugfile = NULL;
	std::ofstream *eventlogfile = NULL;

	bool setLogFiring = false;
	bool keepWebserverRunning = true;
	bool logEvents = false;

	boost::mutex timestep_mutex;
	boost::mutex actionpotential_mutex;
	boost::mutex firingNeurons_mutex;
	boost::mutex timedevents_mutex;
	boost::mutex debug_mutex;

	std::vector <boost::mutex *> teVector_mutex;

	boost::mutex stdp_mutex;


};

#ifndef noexternglobal
#define noexternglobal 1
//Global *globalObject;
#endif

