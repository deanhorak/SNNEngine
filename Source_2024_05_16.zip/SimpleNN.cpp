// SimpleNN.cpp : Defines the entry point for the console application.
//

int mainx(int argc, char* argv[])
{
	return 0;
}

