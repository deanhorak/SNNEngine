#include "Dendrite.h"
#include "Global.h"
#include "Neuron.h"

Dendrite::Dendrite(Neuron *neuron):
	Process(ComponentTypeDendrite)
{

	if (neuron->id == 0 || neuron->id == 0x3F000000) {
		printf("%i", neuron->id);
	}

	Synapse *s = Synapse::create(this);
	synapseId = s->id;
	setRate(DEFAULT_DENDRITE_RATE);
	setDistance(10);
	setNeuronId(neuron->id);
}

Dendrite::Dendrite(Neuron *neuron, long newId):
	Process(ComponentTypeDendrite)
{

	if (newId == 0x3F000000) {
		printf("%i", newId);
	}

	if (neuron->id == 0) {
		printf("%i", neuron->id);
	}

	Synapse *s = Synapse::create(this);
	synapseId = s->id;
	s->setOwningProcessComponentId(newId);
	setRate(DEFAULT_DENDRITE_RATE);
	setDistance(10);
	setNeuronId(neuron->id);

	neuron->setDirty();
}

Dendrite::~Dendrite(void)
{
}

/*
	long neuronId;
	long synapseId
*/
void Dendrite::toJSON(std::ofstream& outstream)
{
	outstream << "                            { \"_type\": \"Dendrite\", \"id\": " << id << ", \"synapseId\": " << synapseId << " } " << std::endl;

}


void Dendrite::save(void)
{
	globalObject->dendriteDB.save(this);
}

void Dendrite::commit(void)
{
	globalObject->dendriteDB.addToCache(this);
}


Dendrite *Dendrite::create(Neuron *neuron)
{

	if (neuron->id == 0) {
		printf("%i", neuron->id);
	}
	if (neuron->id == 0x3F000000) {
		printf("%i", neuron->id);
	}

	long newId = globalObject->nextComponent(ComponentTypeDendrite);
	Dendrite *d = new Dendrite(neuron, newId);
	d->id = newId;
	d->setNeuronId(neuron->id);
	globalObject->insert(d);
	neuron->getDendrites()->push_back(d->id);
	return d;
}

void Dendrite::fire(void)
{

		float lclDistance = getDistance();
		float lclRate = getRate();

		Synapse *s = globalObject->synapseDB.getComponent(this->synapseId);
		long offset = lclDistance * lclRate;
		if(offset < MAX_TIMEINTERVAL_BUFFER_SIZE && offset > 0)
		{
			long ownerId = s->getOwningProcessComponentId();
			Axon *a = globalObject->axonDB.getComponent(ownerId);

			// std::cout << "Dendrite Offset " << offset << std::endl;
			TimedEvent *te = TimedEvent::create(globalObject->current_timestep + offset, a, s->id);
		}
		else 
		{
//			std::cout << "Dendrite Offset " << offset << " too large. ignoring." << std::endl;
		}

	//ActionPotential *ap = ActionPotential::create(this);
//	actionpotentials.insert(std::pair<long,ActionPotential *>(ap->id,ap));

//		std::cout << "Dendrite " << id << " firing " << std::endl;
}

Dendrite::Dendrite(void): 
	Process(ComponentTypeDendrite)
{
	setRate(DEFAULT_DENDRITE_RATE);
	setDistance(7.5);
}

Tuple *Dendrite::getImage(void)
{
/* -- persisted values
	float distance;
	float rate;
	Neuron *neuron;
	Synapse *synapse;
*/

	float lclDistance = getDistance();
	float lclRate = getRate();

	size_t size = sizeof(parentId) + sizeof(lclDistance) + sizeof(lclRate) + sizeof(neuronId) + sizeof(synapseId);

	char *image = globalObject->allocClearedMemory(size);
	char *ptr = (char*)image;



	memcpy(ptr, &parentId, sizeof(parentId)); 		ptr += sizeof(parentId);
	memcpy(ptr,&lclDistance,sizeof(lclDistance)); 	ptr+=sizeof(lclDistance);
	memcpy(ptr,&lclRate,sizeof(lclRate)); 			ptr+=sizeof(lclRate);
	memcpy(ptr,&neuronId,sizeof(neuronId)); 		ptr+=sizeof(neuronId);
	memcpy(ptr,&synapseId,sizeof(synapseId)); 		ptr+=sizeof(synapseId);


	Tuple* tuple = new Tuple();
	tuple->objectPtr = image;
	tuple->value = size;

	return tuple;
}

Dendrite *Dendrite::instantiate(long key, size_t len, void *data)
{
// 	size_t size = sizeof(float)+sizeof(float)+sizeof(long)+sizeof(long);

	Dendrite *dendrite = new Dendrite();
	dendrite->id = key;

	char *ptr = (char*)data;

	float lclDistance = 0;
	float lclRate = 0;

	memcpy(&dendrite->parentId, ptr, sizeof(dendrite->parentId)); 	ptr += sizeof(dendrite->parentId); 
	memcpy(&lclDistance, ptr, sizeof(lclDistance)); 				ptr += sizeof(lclDistance); dendrite->setDistance(lclDistance);
	memcpy(&lclRate, ptr, sizeof(lclRate)); 						ptr += sizeof(lclRate); dendrite->setRate(lclRate);
	memcpy(&dendrite->neuronId,ptr,sizeof(dendrite->neuronId)); 	ptr+=sizeof(dendrite->neuronId); 	
	memcpy(&dendrite->synapseId,ptr,sizeof(dendrite->synapseId)); 	ptr+=sizeof(dendrite->synapseId); 	

	return dendrite;
}

void Dendrite::neuronAdjust(ActionPotential *ap, std::pair<std::vector<Tuple*>*, std::vector<Tuple*>* >* slices)
{ 
	Neuron *n = globalObject->neuronDB.getComponent(neuronId);
	globalObject->applySTDP(n, ap, slices);
	//n->applySTDP(ap); 
};

