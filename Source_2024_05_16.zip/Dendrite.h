#pragma once
#include <map>
#include "Process.h"
#include "ActionPotential.h"

class Synapse;
class Neuron;
class Dendrite: public Process
{
	Dendrite(void);
	Dendrite(Neuron *neuron);
	Dendrite(Neuron *neuron, long newId);
    friend class boost::serialization::access;
    // When the class Archive corresponds to an output archive, the
    // & operator is defined similar to <<.  Likewise, when the class Archive
    // is a type of input archive the & operator is defined similar to >>.
    template<class Archive>
    void serialize(Archive & ar, const size_t version)
	{
		ar & boost::serialization::base_object<NNComponent>(*this);
        ar & neuronId;
		ar & synapseId;
//		std::map<long,ActionPotential *>::iterator itActionPotential = actionpotentials.begin();
//		for (itActionPotential=actionpotentials.begin(); itActionPotential!=actionpotentials.end(); ++itActionPotential)
//		{
//			ar & itActionPotential->second;
//		}
	}

public:
	virtual ~Dendrite(void);
	static Dendrite *create(Neuron *neuron);
//	void cycle(void);
	void fire(void);
//	void removeDeadAPs(void);
	Tuple *getImage(void);
	static Dendrite *instantiate(long key, size_t len, void *data);
	void neuronAdjust(ActionPotential *ap, std::pair<std::vector<Tuple*>*, std::vector<Tuple*>* >* slices);

	inline bool isSameNeuron(long nid) { return neuronId == nid; };
	inline long getNeuronId(void) { return neuronId; };
	inline void setNeuronId(long nId) { this->neuronId = nId; };
	inline long getSynapseId(void) { return synapseId; };
	void toJSON(std::ofstream& outstream);


private:
	void save(void);
	void commit(void);
	long neuronId;
	long synapseId;
//	std::map<long,ActionPotential *> actionpotentials;
};
