#pragma once
class Tuple
{
public:
	char * objectPtr;
	size_t value;
};

