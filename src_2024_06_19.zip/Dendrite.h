#pragma once
#include <map>
#include "Process.h"
#include "ActionPotential.h"

class Synapse;
class Neuron;
class Dendrite: public Process
{
	Dendrite(void);
	Dendrite(Neuron *neuron);
	Dendrite(Neuron *neuron, long newId);
    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive & ar, const size_t version)
	{
		ar & boost::serialization::base_object<NNComponent>(*this);
        ar & preSynapticNeuronId;
		ar & synapseId;
	}

public:
	virtual ~Dendrite(void);
	static Dendrite *create(Neuron *postSynapticNeuron,Neuron *preSynapticNeuron);
	void fire(void);
	Tuple *getImage(void);
	static Dendrite *instantiate(long key, size_t len, void *data);

	inline bool isSameNeuron(long nid) { return preSynapticNeuronId == nid; };
	inline long getNeuronId(void) { return preSynapticNeuronId; };
	inline void setPreSynapticNeuronId(long nId) { this->preSynapticNeuronId = nId; };
	inline long getAssociatedNeuronId(void) { return this->preSynapticNeuronId; };
	inline long getSynapseId(void) { return synapseId; };
	void toJSON(std::ofstream& outstream);


private:
	void save(void);
	void commit(void);
	long preSynapticNeuronId;
	long synapseId;
};
