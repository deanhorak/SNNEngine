#include "Global.h"
#include "Process.h"

Process::Process(ComponentType type): 
	NNComponent(type)
{
}

Process::~Process(void)
{
}

void Process::setRate(float value) 
{ 
	float oldrate = rate;
	if(rate != value) 
	{
		boost::mutex::scoped_lock  amx(process_mutex);
		//std::cout << "Process " << this->id << " rate chg from " << this->rate << " to " << value << std::endl;
		rate = value; 
		setDirty(true); 

//  log upstream rather than here becuasue it has more info (eg pre or post)
		if(globalObject->logEvents) 
		{
			long thisId = 0;
			std::string componenttype("dendrite");
			if(this->id >= globalObject->componentBase[ComponentTypeAxon] && this->id < globalObject->componentBase[ComponentTypeDendrite])
			{ // axon
				Axon *a = (Axon *)this;
				thisId = a->id;
				componenttype = "axon";
			}
			else
			{ // dendrite
				Dendrite *d = (Dendrite *)this;
				thisId = d->id;

			}

			std::stringstream ss;
			ss << componenttype << "_change_rate_change: component=" << thisId << ", oldrate=" << oldrate << ", newrate=" << rate;
			globalObject->writeEventLog(ss.str().c_str());
		}
	}
}