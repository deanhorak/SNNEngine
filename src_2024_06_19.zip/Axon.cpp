#include "Axon.h"
#include "TR1Random.h"
#include "Global.h"
#include "Neuron.h"

Axon::Axon(Neuron *neuron) : Process(ComponentTypeAxon)
{
	if (neuron->id == 0)
	{
		printf("%i", neuron->id);
	}

	this->neuronId = neuron->id;
	setRate(DEFAULT_AXON_RATE);
	float dist = (float)tr1random->generate(1, 1000); // Random # between one and 1000;

	setDistance(dist);
	this->parentId = this->neuronId;
	neuron->setDirty();
}

Axon::~Axon(void)
{
}

/*
	long neuronId;

	std::vector<long> synapses;
*/
void Axon::toJSON(std::ofstream &outstream)
{
	std::string sep("");
	outstream << "                            { \"_type\": \"Axon\", \"id\": " << id << ", \"neuronId\": " << neuronId << ", \"synapses\": [" << std::endl;
	for (unsigned int i = 0; i < synapses.size(); i++)
	{
		outstream << sep;
		sep = ",";
		Synapse *s = globalObject->synapseDB.getComponent(synapses[i]);
		s->toJSON(outstream);
	}
	outstream << "                            ] } " << std::endl;
}

void Axon::save(void)
{
	globalObject->axonDB.save(this);
}

void Axon::commit(void)
{
	globalObject->axonDB.addToCache(this);
}

Axon *Axon::create(Neuron *neuron)
{

	if (neuron->id == 0)
	{
		printf("%i", neuron->id);
	}

	Axon *a = new Axon(neuron);
	a->id = globalObject->nextComponent(ComponentTypeAxon);
	globalObject->insert(a);
	return a;
}

void Axon::initializeRandom(void)
{
	/*
		size_t rnd = (size_t) tr1random->generate(1,10); // Random # of Synapses
		for(size_t i=0;i<rnd;i++)
		{
			Synapse *s = new Synapse();
			//s->initializeRandom();
			synapses.push_back(s);
		}
	*/
}
/*
void Axon::removeDeadAPs(void)
{
	
		bool done = false;
		while(!done)
		{
			done = true;
			CollectionIterator<ActionPotential *> it(&actionpotentials);
			for (it.begin(); it.more(); it.next())
			{
				ActionPotential *ap = it.value();
				if(ap->finished)
				{
					actionpotentials.erase(ap->id);
					done = false;
					break;
				}
			}
		}
	
}
*/


/*
void Axon::cycle(void)
{
	CollectionIterator<ActionPotential *> it(&actionpotentials);
	for (it.begin(); it.more(); it.next())
	{
		ActionPotential *ap = it.value();
		ap->cycle();
	}
	removeDeadAPs();
}
*/

void Axon::insertSynapse(long synapseId)
{
	synapses.push_back(synapseId);
	setDirty();
};

void Axon::fire(void)
{
	for(size_t i = 0;i<this->synapses.size();i++) 
	{
		float lclRate = getRate();

		Synapse *s = globalObject->synapseDB.getComponent(synapses[i]);
		
		long offset = s->getPosition() * lclRate;
		
		if(offset < MAX_TIMEINTERVAL_BUFFER_SIZE && offset > 0)
		{
			long ownerId = s->getOwningProcessComponentId();
			Dendrite *d = globalObject->dendriteDB.getComponent(ownerId);
			// std::cout << "Axon Offset " << offset << std::endl;
			TimedEvent *te = TimedEvent::create(globalObject->current_timestep + offset, d, s->id);
		} 
		else 
		{
//			std::cout << "Axon Offset " << offset << " too large. ignoring." << std::endl;
		}
	}


	//	actionpotentials.insert(std::pair<long,ActionPotential *>(ap->id,ap));

	//	std::cout << "Axon " << id << " firing from Neuron " << this->neuron->id << std::endl;
}

Axon::Axon(void) : Process(ComponentTypeAxon)
{
}

Tuple *Axon::getImage(void)
{
	/* -- persisted values
		float distance;
		float rate;
		Neuron *neuron;
		std::map<long,Synapse *> synapses;
	*/
	long synapseCount = synapses.size();
	float lclDistance = getDistance();
	float lclRate = getRate();

//	int sizeOflong = sizeof(long);
//	int sizeOffloat = sizeof(float);


	size_t size = sizeof(parentId) + sizeof(lclDistance) + sizeof(lclRate) + sizeof(neuronId) +
				  sizeof(synapseCount) + (synapseCount * sizeof(long));

	char *image = globalObject->allocClearedMemory(size);
	char *ptr = (char *)image;

	memcpy(ptr, &parentId, sizeof(parentId));
	ptr += sizeof(parentId);
	memcpy(ptr, &lclDistance, sizeof(lclDistance));
	ptr += sizeof(lclDistance);
	memcpy(ptr, &lclRate, sizeof(lclRate));
	ptr += sizeof(lclRate);
	memcpy(ptr, &neuronId, sizeof(neuronId));
	ptr += sizeof(neuronId);
	memcpy(ptr, &synapseCount, sizeof(synapseCount));
	ptr += sizeof(synapseCount);

	//	if(id == 800000256) {
	// sanity check on # of synapses.
	if (synapseCount > 1000000 || synapseCount < 0)
	{ // max reasonable synapses is 1 million
		printf("getImage: Axon %ld has %ld synapse\n", this->id, synapseCount);
	}
	else
	{
		for (size_t i = 0; i < synapseCount; i++)
		{
			long k = synapses[i];
			memcpy(ptr, &k, sizeof(k));
			ptr += sizeof(k);
		}
	}

	Tuple *tuple = new Tuple();
	tuple->objectPtr = image;
	tuple->value = size;
	return tuple;
}

Axon *Axon::instantiate(long key, size_t len, void *data)
{

	long lclsynapseCount = 0;
	long lclneuronId = 0;
	long lclpId = 0;
	float lclDistance = 0;
	float lclRate = 0;

//	int sizeOflong = sizeof(long);
//	int sizeOffloat = sizeof(float);


	Axon *axon = new Axon();
	axon->id = key;

	char *ptr = (char *)data;
	memcpy(&lclpId, ptr, sizeof(lclpId));
	ptr += sizeof(lclpId);
	memcpy(&lclDistance, ptr, sizeof(lclDistance));
	ptr += sizeof(lclDistance);
	memcpy(&lclRate, ptr, sizeof(lclRate));
	ptr += sizeof(lclRate);
	memcpy(&lclneuronId, ptr, sizeof(lclneuronId));
	ptr += sizeof(lclneuronId);
	memcpy(&lclsynapseCount, ptr, sizeof(lclsynapseCount));
	ptr += sizeof(lclsynapseCount);

	axon->parentId = lclpId;
	axon->setDistance(lclDistance);
	axon->setRate(lclRate);
	axon->neuronId = lclneuronId;


	if (lclsynapseCount > 1000000 || lclsynapseCount < 0) {
		printf("getImage: Axon %ld has %ld synapse\n", axon->id, lclsynapseCount);
	}
	else
	{
		for (size_t i = 0; i < lclsynapseCount; i++)
		{
			long thisKey;
			memcpy(&thisKey, ptr, sizeof(long));
			ptr += sizeof(long);
			axon->synapses.push_back(thisKey);
		}
	}

	axon->setDirty(false);
	return axon;
}
